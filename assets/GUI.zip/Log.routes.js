import LogProvider from '@/providers/Log.provider'

export default [
  { path: '/log', name: 'Log', component: require('@/components/Log'), icon: 'fa-info', group: 'Log services', link: LogProvider.url }
]
