import { URL } from '@/providers/Log.provider'

export default [
  { path: '/log', name: 'Log', component: require('@/components/Log'), gicon: 'fa-video-camera', icon: 'fa-info', group: 'Log services', link: URL }
]
