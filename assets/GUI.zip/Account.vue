<template>
  <Page title="Account management" subtitle="Manage account in project" :breadcrumb="['Oauth service', 'Account']">
    <template slot="others">
      <ConfirmComponent :show="action === -1" title="Do you want to delete it ?" @yes="remove()" @no="item=undefined"></ConfirmComponent>
      <PopupComponent title="User Form" :show="action === 1">
        <template slot="body" v-if="item">
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">username *</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <input class="input" :disabled="item._id" :class="{'is-danger': errors.has('username')}" type="text" placeholder="username" v-model.trim="item.username" name="username" v-validate="'required'">
                </p>
                <p class="help is-danger" v-show="errors.has('username')">{{ errors.first('username') }}</p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">password *</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <input class="input" type="password" placeholder="password" v-model.trim="item.password" name="password">
                </p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">status *</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <span class="select" :class="{'is-danger': errors.has('status')}">
                    <select v-model.trim="item.status" name="status" v-validate="'required'">
                      <option :value="1">Active</option>
                      <option :value="0">Inactive</option>
                    </select>
                  </span>
                </p>
                <p class="help is-danger" v-show="errors.has('status')">{{ errors.first('status') }}</p>
              </div>
              <div class="field has-addons has-addons-centered">
                <p class="help is-success copied" v-show="copied">Copied</p>
                <p class="control is-expanded" :title="copied">
                  <input class="input" readonly type="text" placeholder="Secret key" :value="item.secret_key" @click="copyToClipboard">
                </p>
                <p class="control">
                  <a class="button is-dark" @click="removeSecretkey()" title="Clear secret key">
                    <span class="icon is-small">
                      <i class="fa fa-ban"></i>
                    </span>
                  </a>
                </p>
                <p class="control">
                  <a class="button is-info" @click="generateSecretkey()" title="Generate secret key">
                    <span class="icon">
                      <i class="fa fa-random"></i>
                    </span>
                  </a>
                </p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">recover_by *</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <input class="input" :class="{'is-danger': errors.has('recover_by')}" type="text" placeholder="recover_by" v-model.trim="item.recover_by" name="recover_by" v-validate="'required|email'">
                </p>
                <p class="help is-danger" v-show="errors.has('recover_by')">{{ errors.first('recover_by') }}</p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Role *</label>
            </div>
            <div class="field-body">
              <div class="field is-grouped">
                <p class="control" v-for="r in roles" :key="r._id">
                  <label class="checkbox">
                    <input type="checkbox" name="roles" v-model="item.role_ids" :value="r._id"> {{r.name}}
                  </label>
                </p>
                <p class="help is-danger" v-show="errors.has('roles')">{{ errors.first('roles') }}</p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">More</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <textarea class="textarea" v-model="item.more" name="more" v-validate="'json'"></textarea>
                </p>
                <p class="help is-danger" v-show="errors.has('more')">{{ errors.first('more') }}</p>
              </div>
            </div>
          </div>
        </template>
        <template slot="footer" v-if="item">
          <a class="button is-success" @click="save()" ref="submit">
            <span class="icon">
              <i class="fa fa-floppy-o"></i>
            </span>
            <span>Save changes</span>
          </a>
          <a class="button" @click="closeUpdate()">
            <span class="icon">
              <i class="fa fa-times"></i>
            </span>
            <span>Cancel</span>
          </a>
        </template>
      </PopupComponent>
    </template>
    <template slot="main">
      <TableComponent>
        <template slot="pagination" v-if="list">
          <a class="pagination-previous" title="This is the first page" @click="page <= 1 ? null : fetchData(page - 1)" :disabled="page <= 1">Previous</a>
          <a class="pagination-next" @click="list.length < recordsPerPage ? null : fetchData(page + 1)" :disabled="list.length < recordsPerPage">Next page</a>
          <ul class="pagination-list">
            <li>
              <div class="field has-addons">
                <p class="control">
                  <a class="button is-static">
                    Page {{page}}
                  </a>
                </p>
                <p class="control">
                  <span class="select">
                    <select v-model="recordsPerPage" @change="fetchData(1)">
                      <option :value="20">Show 20 records</option>
                      <option :value="50">Show 50 records</option>
                      <option :value="100">Show 100 records</option>
                    </select>
                  </span>
                </p>
              </div>
            </li>
          </ul>
        </template>
        <template slot="head">
          <tr>
            <th width="1">#</th>
            <th>username</th>
            <th>status</th>
            <th>recover by</th>
            <th>roles</th>
            <th>joined at</th>
            <th>last updated</th>
            <th width="1">
              <a class="button is-primary is-small" v-on:click="openUpdate()">
                <span class="icon is-small">
                  <i class="fa fa-plus-square-o"></i>
                </span>
                <span>Add</span>
              </a>
            </th>
          </tr>
        </template>
        <template slot="body" v-if="list">
          <tr v-for="(e, i) in list" :key="e._id">
            <th>{{(page - 1) * recordsPerPage + i + 1}}</th>
            <td>
              <span class="icon is-pulled-right" v-if="e.app">
                <i class="fa fa-facebook-square has-text-info" v-if="e.app === 'facebook'"></i>
                <i class="fa fa-google-plus-square has-text-danger" v-else-if="e.app === 'google'"></i>
              </span>
              {{ e.username }}
              <span class="tag">{{e._id}}</span>
            </td>
            <td>
              <span class="tag" :class="{ 'is-success': e.status===1 , 'is-danger': e.status===0 }">{{ e.status | $match({1: 'ACTIVED', 0: 'INACTIVED'})}}</span>
            </td>
            <td>{{ e.recover_by }}</td>
            <td>
              <span class="tag is-dark" v-for="r in e.role_ids" :key="r._id">{{ r | $find(roles) | $show('name') }}</span>
            </td>
            <td>{{ e.created_at | $date('DD/MM/YYYY HH:mm') }}</td>
            <td>{{ e.updated_at | $date('DD/MM/YYYY HH:mm') }}</td>
            <td>
              <div class="field has-addons">
                <p class="control" v-if="!e.native || e.username === username">
                  <a class="button is-small is-info" @click="openUpdate(e)">
                    <span class="icon is-small">
                      <i class="fa fa-pencil-square-o"></i>
                    </span>
                    <span>Edit</span>
                  </a>
                </p>
                <p class="control" v-if="!e.native">
                  <a class="button is-small is-dark" @click="item=e._id">
                    <span class="icon is-small">
                      <i class="fa fa-trash-o"></i>
                    </span>
                    <span>Delete</span>
                  </a>
                </p>
              </div>
            </td>
          </tr>
        </template>
      </TableComponent>
    </template>
  </Page>
</template>

<script>
import _ from 'lodash'
import AppConfig from '@/AppConfig'
import { $find, $show, $date, $match } from '@/filters/Core'
import Page from '@/components/template/Page'
import PopupComponent from '@/components/common/Popup.component'
import TableComponent from '@/components/common/Table.component'
import ConfirmComponent from '@/components/common/Confirm.component'
import { AccountProvider, RoleProvider } from '@/providers/Oauth.provider'

export default {
  name: 'list',
  filters: {
    $find,
    $show,
    $date,
    $match
  },
  components: { PopupComponent, ConfirmComponent, Page, TableComponent },
  data() {
    return {
      page: 1,
      recordsPerPage: 20,
      item: undefined,
      list: undefined,
      roles: [],
      copied: undefined,
      username: AppConfig.opts.project.admin
    }
  },
  computed: {
    action() {
      return typeof this.item === 'object' ? 1 : (typeof this.item === 'string' ? -1 : 0)
    }
  },
  mounted() {
    RoleProvider.find().then(roles => {
      this.roles = roles
      this.fetchData()
    })
  },
  watch: {
    $route({ name }) {
      if (name === 'Account') {
        RoleProvider.find().then(roles => {
          this.roles = roles
          this.fetchData()
        })
      }
    }
  },
  methods: {
    fetchData(page = 1) {
      this.page = page
      return AccountProvider.find(undefined, { page: this.page, recordsPerPage: this.recordsPerPage }).then(data => this.list = data)
    },
    openUpdate(item = { status: 1, role_ids: [], more: {} }) {
      this.item = _.cloneDeep(item)
      this.item.more = JSON.stringify(this.item.more, null, '    ')
    },
    closeUpdate(type) {
      this.item = undefined
      if (type) this.$pub('msg', { type: 1, msg: `${type} successfully` })
    },
    save() {
      this.$validator.validateAll().then((isValid) => {
        const tmp = _.clone(this.item)
        tmp.more = JSON.parse(this.item.more)
        if (isValid) {
          if (!tmp._id) {
            AccountProvider.insert(tmp).then(rs => this.fetchData().then(rs => this.closeUpdate('Added')))
          } else {
            AccountProvider.update(tmp).then(rs => this.fetchData().then(rs => this.closeUpdate('Updated')))
          }
        }
      })
    },
    remove() {
      AccountProvider.delete(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Deleted')))
    },
    generateSecretkey() {
      AccountProvider.generateKey(true).then(rs => {
        this.item.secret_key = rs
        this.fetchData()
      })
    },
    removeSecretkey() {
      AccountProvider.generateKey(false).then(rs => {
        this.item.secret_key = ''
        this.fetchData()
      })
    },
    copyToClipboard(e) {
      this.copied = 'Copied to clipboard'
      e.target.select()
      document.execCommand('copy')
      setTimeout(() => {
        this.copied = undefined
      }, 2000)
    }
  }
}
</script> 

<style scoped>
.copied {
  font-weight: bold;
  top: 5px;
  position: relative;
}

.tag {
  margin: 0px 1px;
}
</style>
