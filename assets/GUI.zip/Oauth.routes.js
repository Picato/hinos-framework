import { URL } from '@/providers/Oauth.provider'

export default [
  { path: '/projects', name: 'Projects', component: require('@/components/Projects'), gicon: 'fa-user-secret', icon: 'fa-bank', group: 'Oauth services', superAdmin: true, link: URL, fixed: true },
  { path: '/project', name: 'Project', component: require('@/components/Project'), gicon: 'fa-user-secret', icon: 'fa-bank', group: 'Oauth services', link: URL, fixed: true },
  { path: '/account', name: 'Account', component: require('@/components/Account'), icon: 'fa-user', group: 'Oauth services', link: URL, fixed: true },
  { path: '/role', name: 'Role', component: require('@/components/Role'), icon: 'fa-lock', group: 'Oauth services', link: URL, fixed: true }
]
