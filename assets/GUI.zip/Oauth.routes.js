import ProjectProvider from '@/providers/Project.provider'

export default [
  { path: '/projects', name: 'Projects', component: require('@/components/Projects'), icon: 'fa-bank', group: 'Oauth services', superAdmin: true, link: ProjectProvider.url, fixed: true },
  { path: '/project', name: 'Project', component: require('@/components/Project'), icon: 'fa-bank', group: 'Oauth services', link: ProjectProvider.url, fixed: true },
  { path: '/account', name: 'Account', component: require('@/components/Account'), icon: 'fa-user', group: 'Oauth services', link: ProjectProvider.url, fixed: true },
  { path: '/role', name: 'Role', component: require('@/components/Role'), icon: 'fa-lock', group: 'Oauth services', link: ProjectProvider.url, fixed: true }
]
