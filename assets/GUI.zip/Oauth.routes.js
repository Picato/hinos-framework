import ProjectProvider from '@/providers/Project.provider'

export default [
  { path: '/projects', name: 'Projects', component: require('@/components/Projects'), icon: 'fa-bank', group: 'Oauth services', superAdmin: true, fixed: true, link: ProjectProvider.url },
  { path: '/project', name: 'Project', component: require('@/components/Project'), icon: 'fa-bank', group: 'Oauth services', fixed: true, link: ProjectProvider.url },
  { path: '/account', name: 'Account', component: require('@/components/Account'), icon: 'fa-user', group: 'Oauth services', fixed: true, link: ProjectProvider.url },
  { path: '/role', name: 'Role', component: require('@/components/Role'), icon: 'fa-lock', group: 'Oauth services', fixed: true, link: ProjectProvider.url }
]
