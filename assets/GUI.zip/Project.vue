<template>
  <Page v-if="item" :title="item.name" :subtitle="'#'+item._id" :breadcrumb="['Oauth service', 'Project details']">
    <template slot="main">
      <div class="has-text-right content">
        <div class="tag">
          Created at: {{item.created_at | $date('DD/MM/YYYY HH:mm')}}
        </div>
        <div class="tag">
          Last updated at: {{item.updated_at | $date('DD/MM/YYYY HH:mm')}}
        </div>
      </div>
      <div class="field is-horizontal">
        <div class="field-label is-normal">
          <label class="label">Description</label>
        </div>
        <div class="field-body">
          <div class="field">
            <p class="control">
              <textarea class="textarea" v-model.trim="item.des" name="des"></textarea>
            </p>
          </div>
        </div>
      </div>
      <div class="field is-horizontal">
        <div class="field-label is-normal">
          <label class="label">Configuration</label>
        </div>
        <div class="field-body">
          <div class="field">
            <p class="control has-addons">
              <label class="label is-small">Session expire time (second)</label>
              <input class="input" type="number" name="expired" placeholder="Session expired" v-model.number="item.plugins.oauth.session_expired" v-validate="'required'">
            </p>
            <p class="help is-danger" v-show="errors.has('expired')">{{ errors.first('expired') }}</p>
          </div>
          <div class="field">
            <label class="label is-small">Allow login via social network</label>
            <p class="control">
              <label class="checkbox">
                <input type="checkbox" :value="'facebook'" v-model="item.plugins.oauth.app" name="app"> Facebook
              </label>
            </p>
          </div>
        </div>
      </div>
      <div class="field is-horizontal">
        <div class="field-label is-normal"></div>
        <div class="field-body">
          <div class="field">
            <p class="control">
              <label class="checkbox">
                <input type="checkbox" v-model="item.plugins.oauth.single_mode"> Single mode
              </label>
            </p>
            <p class="help is-info">Only allow a single login per user at a time</p>
          </div>
          <div class="field">
            <p class="control">
              <label class="checkbox">
                <input type="checkbox" v-model="item.plugins.oauth.is_verify"> Is verify
              </label>
            </p>
            <p class="help is-info">Allow auto active account immediately after register</p>
          </div>
        </div>
      </div>
      <div class="field is-horizontal">
        <div class="field-label is-normal"></div>
        <div class="field-body">
          <a class="button is-success" @click="save()">
            <span class="icon">
              <i class="fa fa-floppy-o"></i>
            </span>
            <span>Save changes</span>
          </a>
        </div>
      </div>
    </template>
  </Page>
</template>

<script>
import { $find, $show, $date } from '@/filters/Core'
import Page from '@/components/template/Page'
import PopupComponent from '@/components/common/Popup.component'
import ConfirmComponent from '@/components/common/Confirm.component'
import { ProjectProvider } from '@/providers/Oauth.provider'

export default {
  name: 'list',
  filters: {
    $find,
    $show,
    $date,
    $status(value) {
      return value === 0 ? 'INACTIVE' : 'ACTIVED'
    }
  },
  components: { PopupComponent, ConfirmComponent, Page },
  data() {
    return {
      item: undefined
    }
  },
  mounted() {
    ProjectProvider.get().then(data => {
      this.item = data
    })
  },
  methods: {
    save() {
      this.$validator.validateAll().then((isValid) => {
        if (isValid) {
          ProjectProvider.updateMine(this.item).then(() => {
            this.$pub('msg', { type: 1, msg: `Updated successfully` })
          })
        }
      })
    }
  }
}
</script>

