<template>
  <Page title="Log management" subtitle="Manage log in project" :breadcrumb="['Log service', 'Log']">
    <template slot="others">
      <ConfirmComponent :show="action === -1" title="Do you want to delete it ?" @yes="remove()" @no="item=undefined"></ConfirmComponent>
      <PopupComponent title="Log Form details" :show="action === 1">
        <template slot="body" v-if="item">
          <nav class="panel">
            <p class="panel-heading">
              {{item.title}}
            </p>
            <a class="panel-block is-active">
              <div style="width: 50%" title="created at">
                <b>[created_at]</b>&nbsp; {{item.created_at | $date('DD/MM/YYYY hh:mm:ss')}}
              </div>
              <div style="width: 50%" title="updated at">
                <b>[updated_at]</b>&nbsp; {{item.updated_at | $date('DD/MM/YYYY hh:mm:ss')}}
              </div>
            </a>
            <a class="panel-block is-active">
              <b>[type]</b>&nbsp;{{item.type}}
            </a>
            <a class="panel-block is-active">
              <b>[status]</b>&nbsp;{{item.status}}
            </a>
            <a class="panel-block" v-for="(vl, key) in item" :key="key" v-if="['title', 'status', 'type', 'created_at', 'updated_at', '_id', 'project_id', 'account_id'].indexOf(key) === -1">
              <b>[{{key}}]</b>&nbsp;{{vl}}
            </a>
          </nav>
        </template>
        <template slot="footer" v-if="item">
          <a class="button" @click="closeUpdate()">
            <span class="icon">
              <i class="fa fa-times"></i>
            </span>
            <span>Close</span>
          </a>
        </template>
      </PopupComponent>
    </template>
    <template slot="main">
      <TableComponent>
        <template slot="pagination" v-if="list">
          <a class="pagination-previous" title="This is the first page" @click="page <= 1 ? null : fetchData(page - 1)" :disabled="page <= 1">Previous</a>
          <a class="pagination-next" @click="list.length < recordsPerPage ? null : fetchData(page + 1)" :disabled="list.length < recordsPerPage">Next page</a>
          <ul class="pagination-list">
            <li>
              <div class="field has-addons">
                <p class="control">
                  <a class="button is-static">
                    Page {{page}}
                  </a>
                </p>
                <p class="control">
                  <span class="select">
                    <select v-model="recordsPerPage" @change="fetchData(1)">
                      <option :value="20">Show 20 records</option>
                      <option :value="50">Show 50 records</option>
                      <option :value="100">Show 100 records</option>
                    </select>
                  </span>
                </p>
              </div>
            </li>
          </ul>
        </template>
        <template slot="head">
          <tr>
            <th width="1">#</th>
            <th width="1">
              <abbr>_id</abbr>
            </th>
            <th>
              <abbr>title</abbr>
            </th>
            <th>
              <abbr>type</abbr>
            </th>
            <th>
              <abbr>status</abbr>
            </th>
            <th>
              <abbr>created_at</abbr>
            </th>
            <th>
              <abbr>updated_at</abbr>
            </th>
            <th width="1">
            </th>
          </tr>
        </template>
        <template slot="body" v-if="list">
          <tr v-for="(e, i) in list" :key="e._id">
            <th>{{(page - 1) * recordsPerPage + i + 1}}</th>
            <td>{{ e._id }}</td>
            <td>{{ e.title }}</td>
            <td>{{ e.type }}</td>
            <td>{{ e.status }}</td>
            <td>{{ e.created_at | $date('DD/MM/YYYY hh:mm:ss') }}</td>
            <td>{{ e.updated_at | $date('DD/MM/YYYY hh:mm:ss') }}</td>
            <td>
              <div class="field has-addons">
                <p class="control">
                  <a class="button is-small is-info" @click="openUpdate(e)">
                    <span class="icon is-small">
                      <i class="fa fa-eye"></i>
                    </span>
                    <span>Details</span>
                  </a>
                </p>
                <p class="control">
                  <a class="button is-small is-dark" @click="item=e._id">
                    <span class="icon is-small">
                      <i class="fa fa-trash-o"></i>
                    </span>
                    <span>Delete</span>
                  </a>
                </p>
              </div>
            </td>
          </tr>
        </template>
      </TableComponent>
    </template>
  </Page>
</template>

<script>
import { $find, $show, $date } from '@/filters/Core'
import Page from '@/components/template/Page'
import PopupComponent from '@/components/common/Popup.component'
import TableComponent from '@/components/common/Table.component'
import ConfirmComponent from '@/components/common/Confirm.component'
import LogProvider from '@/providers/Log.provider'

export default {
  name: 'list',
  filters: { $find, $show, $date },
  components: { PopupComponent, ConfirmComponent, Page, TableComponent },
  data() {
    return {
      page: 1,
      recordsPerPage: 20,
      item: undefined,
      list: undefined
    }
  },
  computed: {
    action() {
      return typeof this.item === 'object' ? 1 : (typeof this.item === 'string' ? -1 : 0)
    }
  },
  mounted() {
    this.fetchData()
  },
  watch: {
    '$route'({ name }) {
      if (name === 'Log') this.fetchData()
    }
  },
  methods: {
    fetchData(page = 1) {
      this.page = page
      return LogProvider.find(undefined, { page: this.page, recordsPerPage: this.recordsPerPage }).then(data => this.list = data)
    },
    openUpdate(item) {
      this.item = item
    },
    closeUpdate(type) {
      this.item = undefined
      if (type) this.$pub('msg', { type: 1, msg: `${type} successfully` })
    },
    remove() {
      LogProvider.delete(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Deleted')))
    }
  }
}
</script> 
