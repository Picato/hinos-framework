<template>
  <Page title="Gateway" subtitle="List all services use in gateway" :breadcrumb="['Manager', 'Gateway']">
    <template slot="main">
      <div class="has-text-centered">
        <span class="icon is-very-large has-text-primary">
          <i class="fa fa-globe"></i>
        </span>
      </div>
      <br/>
      <div class="has-text-centered">
        <span class="icon is-large">
          <i class="fa fa-long-arrow-down"></i>
        </span>
      </div>
      <br/>
      <div class="tile">
        <div class="tile is-parent is-1"></div>
        <div class="tile is-parent is-10">
          <div class="tile is-child box notification has-text-centered is-primary">
            <p class="title">Gateway</p>
            <p>{{url.substr(0, url.lastIndexOf('/'))}}</p>
            <br/>
            <span class="icon is-large">
              <i class="fa fa-cogs"></i>
            </span>
          </div>
        </div>
      </div>
      <br/>
      <div class="has-text-centered">
        <span class="icon is-large">
          <i class="fa fa-long-arrow-down"></i>
        </span>
      </div>
      <br/>
      <div class="tile">
        <div class="tile">
          <div class="tile is-child box has-text-centered notification">
            <div class="block">
              <h1 class="title">Micro Services</h1>
              <div class="box notification is-success is-pulled-left" v-for="service in list" :key="service._id">
                <a class="delete is-small" @click="remove(service)"></a>
                <div class="tag is-large" style="cursor: pointer">
                  /{{service.name.toUpperCase()}}
                </div>
                <br/>
                <br/>
                <div>{{service.link}}</div>
              </div>
              <div class="box notification is-pulled-left">
                <form @submit.prevent="add()" class="has-text-left">
                  <div class="field">
                    <label class="label" title="http://localhost:1002/files => files">Service name</label>
                    <p class="control">
                      <input class="input" :class="{'is-danger': errors.has('name')}" type="text" placeholder="oauth" v-model.trim="item.name" name="name" v-validate="'required'">
                    </p>
                    <p class="help is-danger" v-show="errors.has('name')">{{ errors.first('name') }}</p>
                  </div>
                  <div class="field">
                    <label class="label" title="localhost:1002">Root url & ip</label>
                    <p class="control">
                      <input class="input" :class="{'is-danger': errors.has('link')}" type="text" placeholder="localhost:6111" v-model.trim="item.link" name="link" v-validate="'required'">
                    </p>
                    <p class="help is-danger" v-show="errors.has('link')">{{ errors.first('link') }}</p>
                  </div>
                  <br/>
                  <button class="button is-primary" type="submit">
                    <span class="icon">
                      <i class="fa fa-plus"></i>
                    </span>
                    &nbsp;&nbsp;Add New service
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </template>
  </Page>
</template>

<script>
import { $find, $show, $date } from '@/filters/Core'
import Page from '@/components/template/Page'
import PopupComponent from '@/components/common/Popup.component'
import ConfirmComponent from '@/components/common/Confirm.component'
import { GatewayProvider, URL } from '@/providers/Gateway.provider'
import PluginJson from '../../build/plugin.json'

export default {
  name: 'list',
  filters: {
    $find,
    $show,
    $date
  },
  components: { PopupComponent, ConfirmComponent, Page },
  data() {
    return {
      url: URL,
      plugins: PluginJson,
      gateway: {},
      list: [],
      item: {}
    }
  },
  mounted() {
    this.fetchData()
  },
  watch: {
    $route({ name }) {
      if (name === 'Log') this.fetchData()
    }
  },
  methods: {
    fetchData(page = 1) {
      this.page = page
      return GatewayProvider.findService(undefined, { page: this.page, recordsPerPage: this.recordsPerPage }).then(data => this.list = data)
    },
    add() {
      this.$validator.validateAll().then((isValid) => {
        if (isValid) {
          if (!this.item._id) {
            if (this.item.link.indexOf('http') !== 0) this.item.link = 'http://' + this.item.link
            GatewayProvider.insertService(this.item).then(rs => {
              this.item = {}
              this.fetchData().then(rs => this.$pub('msg', { type: 1, msg: `Added successfully` }))
            })
          }
        }
      })
    },
    remove(service) {
      GatewayProvider.deleteService(service._id).then(rs => this.fetchData().then(rs => this.$pub('msg', { type: 1, msg: `Deleted successfully` })))
    }
  }
}
</script>
<style scoped>
.block>.box {
  margin: 16px;
  float: left;
  width: 21%;
  padding: 16px 0px 0px;
}

.block>.box:last-child {
  padding: 16px;
}

pre {
  width: 100%;
  max-height: 200px;
  overflow-y: auto;
  padding: 4px 8px;
  margin-top: 8px;
  font-size: 10px;
}

.icon.is-very-large {
  height: 7.5rem;
  width: 7.5rem;
}

.icon.is-very-large .fa {
  font-size: 125px;
}
</style>
