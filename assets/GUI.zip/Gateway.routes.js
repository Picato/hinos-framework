import { URL } from '@/providers/Gateway.provider'

export default [
  { path: '/gateway-config', name: 'Gateway-Config', component: require('@/components/Gateway'), gicon: 'fa-globe', icon: 'fa-code-fork', group: 'Gateway services', link: URL, superAdmin: true },
  { path: '/gateway', name: 'Gateway', component: require('@/components/Gateway'), icon: 'fa-code-fork', group: 'Gateway services', link: URL }
]
