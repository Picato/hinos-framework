import { URL } from '@/providers/Gateway.provider'

export default [
  { path: '/gateway', name: 'Gateway', component: require('@/components/Gateway'), icon: 'fa-code-fork', group: 'Gateway services', link: URL }
]
