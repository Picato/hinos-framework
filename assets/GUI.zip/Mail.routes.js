import { URL } from '@/providers/Mail.provider'

export default [
  { path: '/mailconfig', name: 'MailConfig', component: require('@/components/MailConfig'), gicon: 'fa-envelope-o', icon: 'fa-wrench', group: 'Mail services', link: URL },
  { path: '/mail', name: 'Mail', component: require('@/components/Mail'), icon: 'fa-envelope', group: 'Mail services', link: URL }
]
