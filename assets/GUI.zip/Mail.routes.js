import MailConfigProvider from '@/providers/MailConfig.provider'

export default [
  { path: '/mailconfig', name: 'MailConfig', component: require('@/components/MailConfig'), icon: 'fa-wrench', group: 'Mail services', link: MailConfigProvider.url },
  { path: '/mail', name: 'Mail', component: require('@/components/Mail'), icon: 'fa-envelope', group: 'Mail services', link: MailConfigProvider.url }
]
