import axios from 'axios'

export const URL = '${url}'

export const ScriptProvider = {
  getDownloadLink(sc) {
    if (sc.is_private) return `${URL}/Download?id=${sc._id}`
    return `${URL}/Download?name=${sc.name}`
  },
  find(where, opts = { page: 1, recordsPerPage: 20 }) {
    return axios.get(`${URL}`, {
      params: Object.assign(opts, where)
    }).then(resp => resp.data)
  },
  get(item) {
    return axios.get(`${URL}/${item._id}`, item).then(resp => resp.data)
  },
  insert(item) {
    return axios.post(`${URL}`, item).then(resp => resp.data)
  },
  update(item) {
    return axios.put(`${URL}/${item._id}`, item).then(resp => resp.data)
  },
  delete(_id) {
    return axios.delete(`${URL}/${_id}`).then(resp => resp.data)
  }
}
