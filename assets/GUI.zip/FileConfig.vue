<template>
  <Page title="Uploading file configuration management" subtitle="Manage file config in project" :breadcrumb="['File service', 'Uploading config']">
    <template slot="others">
      <Confirm :show="action === -1" title="Do you want to delete it ?" @yes="remove()" @no="item=undefined"></Confirm>
      <Popup title="FileConfig Form" :show="action === 1">
        <template slot="body" v-if="item && item.config">
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Name</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control has-icons-right">
                  <input class="input" :class="{'is-danger': errors.has('name')}" type="text" v-model.trim="item.name" name="name" v-validate="'required'">
                </p>
                <p class="help is-danger" v-show="errors.has('name')">{{ errors.first('name') }}</p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Max size</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control has-icons-right">
                  <input class="input" :class="{'is-danger': errors.has('maxsize')}" type="number" placeholder="kbs" v-model.number="item.config.maxSize" name="maxsize" v-validate="'required'">
                  <span class="icon is-small is-right">
                    <i class="fa">/ kbs</i>
                  </span>
                </p>
                <p class="help is-danger" v-show="errors.has('maxsize')">{{ errors.first('maxsize') }}</p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Max files</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <input class="input" :class="{'is-danger': errors.has('maxfile')}" type="number" placeholder="Number of files" v-model.number="item.config.maxFile" name="maxfile" v-validate="'required'">
                </p>
                <p class="help is-danger" v-show="errors.has('maxfile')">{{ errors.first('maxfile') }}</p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Extension</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <input class="input" :class="{'is-danger': errors.has('ext')}" type="text" placeholder="jpe?g|png|gif" v-model.trim="item.config.ext" name="ext" v-validate="'required'">
                </p>
                <p class="help is-danger" v-show="errors.has('ext')">{{ errors.first('ext') }}</p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal"></div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <label class="checkbox">
                    <input type="checkbox" v-model.trim="item.config.zip"> Auto compress files
                  </label>
                </p>
              </div>
            </div>
          </div>
          <nav class="panel" v-if="!item.config.zip">
            <div class="panel-block is-active relative">
              <span class="panel-icon">
                <i class="fa fa-expand"></i>
              </span>
              Auto resize image
              <div class="has-text-right absolute" style="top: 6px; right: 8px">
                <a class="button is-small is-primary" @click="addResize(item.config.resize)">
                  <span class="icon is-small">
                    <i class="fa fa-plus"></i>
                  </span>
                  <span>Add size</span>
                </a>
              </div>
            </div>
            <a class="panel-block" v-for="(p, i) in item.config.resize" :key="i">
              <div class="field is-grouped" style="width: 100%">
                <p class="control has-icons-left">
                  <input class="input is-small" type="number" placeholder="image width" v-model.number="p.w">
                  <span class="icon is-small is-left">
                    <i class="fa fa-text-width"></i>
                  </span>
                </p>&nbsp;
                <p class="control has-icons-left">
                  <input class="input is-small" type="number" placeholder="image height" v-model.number="p.h">
                  <span class="icon is-small is-left">
                    <i class="fa fa-text-height"></i>
                  </span>
                </p>&nbsp;
                <p class="control has-icons-right">
                  <input class="input is-small" type="text" placeholder="thumb => file.thumb.jpg" v-model.trim="p.ext">
                  <span class="icon is-small is-right">
                    <i class="fa fa-file-word-o"></i>
                  </span>
                </p>
              </div>
            </a>
          </nav>
        </template>
        <template slot="footer" v-if="item">
          <a class="button is-success" @click="save()" ref="submit">
            <span class="icon">
              <i class="fa fa-floppy-o"></i>
            </span>
            <span>Save changes</span>
          </a>
          <a class="button" @click="closeUpdate()">
            <span class="icon">
              <i class="fa fa-times"></i>
            </span>
            <span>Cancel</span>
          </a>
        </template>
      </Popup>
    </template>
    <template slot="main">
      <TableComponent>
        <template slot="pagination" v-if="list">
          <a class="pagination-previous" title="This is the first page" @click="page <= 1 ? null : fetchData(page - 1)" :disabled="page <= 1">Previous</a>
          <a class="pagination-next" @click="list.length < recordsPerPage ? null : fetchData(page + 1)" :disabled="list.length < recordsPerPage">Next page</a>
          <ul class="pagination-list">
            <li>
              <div class="field has-addons">
                <p class="control">
                  <a class="button is-static">
                    Page {{page}}
                  </a>
                </p>
                <p class="control">
                  <span class="select">
                    <select v-model="recordsPerPage" @change="fetchData(1)">
                      <option :value="20">Show 20 records</option>
                      <option :value="50">Show 50 records</option>
                      <option :value="100">Show 100 records</option>
                    </select>
                  </span>
                </p>
              </div>
            </li>
          </ul>
        </template>
        <template slot="head">
          <tr>
            <th width="1">#</th>
            <th>name</th>
            <th>created_at</th>
            <th>updated_at</th>
            <th width="1">
              <a class="button is-primary is-small" v-on:click="openUpdate()">
                <span class="icon is-small">
                  <i class="fa fa-plus-square-o"></i>
                </span>
                <span>Add</span>
              </a>
            </th>
          </tr>
        </template>
        <template slot="body" v-if="list">
          <tr v-for="(e, i) in list" :key="e._id">
            <th>{{(page - 1) * recordsPerPage + i + 1}}</th>
            <td>
              {{ e.name }}
              <span class="tag">{{ e._id }}</span>
              <p class="control is-pulled-right">
                <FileComponent text="Upload" :zip="e.config.zip" :small="true" :multiple="e.config.maxFile > 1" :to="uploadUrl+'/Upload/'+e._id" name="files" @done="upload()" @error="upload"></FileComponent>
              </p>
            </td>
            <td>{{ e.created_at | $date('DD/MM/YYYY hh:mm') }}</td>
            <td>{{ e.updated_at | $date('DD/MM/YYYY hh:mm') }}</td>
            <td>
              <div class="field has-addons">
                <p class="control">
                  <a class="button is-small is-info" @click="openUpdate(e)">
                    <span class="icon is-small">
                      <i class="fa fa-pencil-square-o"></i>
                    </span>
                    <span>Edit</span>
                  </a>
                </p>
                <p class="control">
                  <a class="button is-small is-dark" @click="item=e._id">
                    <span class="icon is-small">
                      <i class="fa fa-trash-o"></i>
                    </span>
                    <span>Delete</span>
                  </a>
                </p>
              </div>
            </td>
          </tr>
        </template>
      </TableComponent>
    </template>
  </Page>
</template>

<script>
import _ from 'lodash'
import { $find, $show, $date } from '@/filters/Core'
import Page from '@/components/template/Page'
import Popup from '@/components/common/Popup'
import TableComponent from '@/components/common/Table.component'
import FileComponent from '@/components/common/File.component'
import Confirm from '@/components/common/Confirm'
import FileConfigProvider from '@/providers/FileConfig.provider'
import FileProvider from '@/providers/Files.provider'

export default {
  name: 'list',
  filters: { $find, $show, $date },
  components: { Popup, Confirm, Page, TableComponent, FileComponent },
  data() {
    return {
      page: 1,
      recordsPerPage: 20,
      uploadUrl: FileProvider.url,
      item: undefined,
      list: undefined
    }
  },
  computed: {
    action() {
      return typeof this.item === 'object' ? 1 : (typeof this.item === 'string' ? -1 : 0)
    }
  },
  mounted() {
    this.fetchData()
  },
  watch: {
    '$route'({ name }) {
      if (name === 'FileConfig') this.fetchData()
    }
  },
  methods: {
    upload(err) {
      if (!err) return this.$pub('msg', { type: 1, msg: `Uploaded successfully` })
      console.error(err)
    },
    fetchData(page = 1) {
      this.page = page
      return FileConfigProvider.find(undefined, { page: this.page, recordsPerPage: this.recordsPerPage }).then(data => this.list = data)
    },
    openUpdate(item = { config: { maxSize: 2046, maxFile: 2, ext: '.*', resize: [] } }) {
      this.item = _.cloneDeep(item)
    },
    closeUpdate(type) {
      this.item = undefined
      if (type) this.$pub('msg', { type: 1, msg: `${type} successfully` })
    },
    addResize(resize) {
      if (resize.find(e => (!e.w && !e.h) || !e.ext)) return
      resize.push({ w: undefined, h: undefined, ext: undefined })
    },
    save() {
      if (this.item.config.zip) this.item.config.resize = []
      else this.item.config.resize = this.item.config.resize.filter(e => (e.w || e.h) && e.ext)
      this.$validator.validateAll().then((isValid) => {
        if (isValid) {
          if (!this.item._id) {
            FileConfigProvider.insert(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Added')))
          } else {
            FileConfigProvider.update(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Updated')))
          }
        }
      })
    },
    remove() {
      FileConfigProvider.delete(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Deleted')))
    }
  }
}
</script> 
