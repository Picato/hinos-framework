import axios from 'axios'

export const URL = '${url}'

export const MailProvider = {
  find(where, opts = { page: 1, recordsPerPage: 20 }) {
    return axios.get(`${URL}`, {
      params: opts
    }).then(resp => resp.data)
  },
  get(item) {
    return axios.get(`${URL}/${item._id}`, item).then(resp => resp.data)
  },
  insert(item) {
    return axios.post(`${URL}`, item).then(resp => resp.data)
  },
  resend(item) {
    return axios.put(`${URL}/Resend/${item._id}`, item).then(resp => resp.data)
  },
  delete(_id) {
    return axios.delete(`${URL}/${_id}`).then(resp => resp.data)
  }
}

export const MailConfigProvider = {
  test(item) {
    return axios.post(`${URL}/Test`, item).then(resp => resp.data)
  },
  find(where, opts = { page: 1, recordsPerPage: 20 }) {
    return axios.get(`${URL}/Config`, {
      params: opts
    }).then(resp => resp.data)
  },
  insert(item) {
    return axios.post(`${URL}/Config`, item).then(resp => resp.data)
  },
  update(item) {
    return axios.put(`${URL}/Config/${item._id}`, item).then(resp => resp.data)
  },
  delete(_id) {
    return axios.delete(`${URL}/Config/${_id}`).then(resp => resp.data)
  }
}
