import axios from 'axios'
import MailConfigProvider from '@/providers/MailConfig.provider'

export default {
  url: MailConfigProvider.url,
  find(where, opts = { page: 1, recordsPerPage: 20 }) {
    return axios.get(`${this.url}/Mail`, {
      params: opts
    }).then(resp => resp.data)
  },
  get(item) {
    return axios.get(`${this.url}/Mail/${item._id}`, item).then(resp => resp.data)
  },
  insert(item) {
    return axios.post(`${this.url}/Mail`, item).then(resp => resp.data)
  },
  resend(item) {
    return axios.put(`${this.url}/Resend/${item._id}`, item).then(resp => resp.data)
  },
  delete(_id) {
    return axios.delete(`${this.url}/Mail/${_id}`).then(resp => resp.data)
  }
}
