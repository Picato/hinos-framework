<template>
  <Page title="Mail configuration management" subtitle="Manage mail configuration in project" :breadcrumb="['Mail service', 'Mail config']">
    <template slot="others">
      <ConfirmComponent :show="action === -1" title="Do you want to delete it ?" @yes="remove()" @no="item=undefined"></ConfirmComponent>
      <PopupComponent title="MailConfig Form" :show="action === 1">
        <template slot="body" v-if="item && item.config">
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">name *</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <input class="input" :class="{'is-danger': errors.has('name')}" type="text" placeholder="name" v-model.trim="item.name" name="name" v-validate="'required'">
                </p>
                <p class="help is-danger" v-show="errors.has('name')">{{ errors.first('name') }}</p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">host *</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <input class="input" :class="{'is-danger': errors.has('host')}" type="text" placeholder="host" v-model.trim="item.config.host" name="host" v-validate="'required'">
                </p>
                <p class="help is-danger" v-show="errors.has('host')">{{ errors.first('host') }}</p>
              </div>
              <div class="field">
                <p class="control">
                  <input class="input" :class="{'is-danger': errors.has('port')}" type="number" placeholder="port" v-model.number="item.config.port" name="port" v-validate="'required'">
                </p>
                <p class="help is-danger" v-show="errors.has('port')">{{ errors.first('port') }}</p>
              </div>
              <div class="field">
                <p class="control">
                  <label class="checkbox">
                    <input type="checkbox" v-model="item.config.secure"> SSL
                  </label>
                </p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">user *</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <input class="input" :class="{'is-danger': errors.has('user')}" type="text" placeholder="user" v-model.trim="item.config.auth.user" name="user" v-validate="'required'">
                </p>
                <p class="help is-danger" v-show="errors.has('user')">{{ errors.first('user') }}</p>
              </div>
              <div class="field">
                <p class="control">
                  <input class="input" :class="{'is-danger': errors.has('pass')}" type="password" placeholder="pass" v-model.trim="item.config.auth.pass" name="pass" v-validate="'required'">
                </p>
                <p class="help is-danger" v-show="errors.has('pass')">{{ errors.first('pass') }}</p>
              </div>
            </div>
          </div>
        </template>
        <template slot="footer" v-if="item">
          <a class="button is-success" @click="save()" ref="submit">
            <span class="icon">
              <i class="fa fa-floppy-o"></i>
            </span>
            <span>Save changes</span>
          </a>
          <a class="button" @click="closeUpdate()">
            <span class="icon">
              <i class="fa fa-times"></i>
            </span>
            <span>Cancel</span>
          </a>
          <div class="field has-addons" style="position: absolute; right: 20px">
            <p class="control">
              <input class="input" type="email" placeholder="Receving email" v-model="item.to" name="receive" v-validate="'email'" :disabled="isTesting">
            </p>
            <p class="control">
              <a class="button is-info" @click="test()" :class="{'is-loading': isTesting}" :disabled="!item.to">
                <span class="icon is-small">
                  <i class="fa fa-play"></i>
                </span>
                <span>Test</span>
              </a>
            </p>
            <p class="help is-danger" style="position: absolute; bottom: -18px;" v-show="errors.has('receive')">{{ errors.first('receive') }}</p>
          </div>
        </template>
      </PopupComponent>
    </template>
    <template slot="main">
      <TableComponent>
        <template slot="pagination" v-if="list">
          <a class="pagination-previous" title="This is the first page" @click="page <= 1 ? null : fetchData(page - 1)" :disabled="page <= 1">Previous</a>
          <a class="pagination-next" @click="list.length < recordsPerPage ? null : fetchData(page + 1)" :disabled="list.length < recordsPerPage">Next page</a>
          <ul class="pagination-list">
            <li>
              <div class="field has-addons">
                <p class="control">
                  <a class="button is-static">
                    Page {{page}}
                  </a>
                </p>
                <p class="control">
                  <span class="select">
                    <select v-model="recordsPerPage" @change="fetchData(1)">
                      <option :value="20">Show 20 records</option>
                      <option :value="50">Show 50 records</option>
                      <option :value="100">Show 100 records</option>
                    </select>
                  </span>
                </p>
              </div>
            </li>
          </ul>
        </template>
        <template slot="head">
          <tr>
            <th width="1">#</th>
            <th>name</th>
            <th>config</th>
            <th width="1">
              <a class="button is-primary is-small" v-on:click="openUpdate()">
                <span class="icon is-small">
                  <i class="fa fa-plus-square-o"></i>
                </span>
                <span>Add</span>
              </a>
            </th>
          </tr>
        </template>
        <template slot="body" v-if="list">
          <tr v-for="(e, i) in list" :key="e._id">
            <th>{{(page - 1) * recordsPerPage + i + 1}}</th>
            <td>
              {{ e.name }}
              <span class="tag">{{ e._id }}</span>
            </td>
            <td>{{ e.config.host }}</td>
            <td>
              <div class="field has-addons">
                <p class="control">
                  <a class="button is-small is-info" @click="openUpdate(e)">
                    <span class="icon is-small">
                      <i class="fa fa-pencil-square-o"></i>
                    </span>
                    <span>Edit</span>
                  </a>
                </p>
                <p class="control">
                  <a class="button is-small is-dark" @click="item=e._id">
                    <span class="icon is-small">
                      <i class="fa fa-trash-o"></i>
                    </span>
                    <span>Delete</span>
                  </a>
                </p>
              </div>
            </td>
          </tr>
        </template>
      </TableComponent>
    </template>
  </Page>
</template>

<script>
import _ from 'lodash'
import { $find, $show, $date } from '@/filters/Core'
import Page from '@/components/template/Page'
import PopupComponent from '@/components/common/Popup.component'
import TableComponent from '@/components/common/Table.component'
import ConfirmComponent from '@/components/common/Confirm.component'
import { MailConfigProvider } from '@/providers/Mail.provider'

export default {
  name: 'list',
  filters: { $find, $show, $date },
  components: { PopupComponent, ConfirmComponent, Page, TableComponent },
  data() {
    return {
      page: 1,
      recordsPerPage: 20,
      item: undefined,
      list: undefined,
      isTesting: undefined
    }
  },
  computed: {
    action() {
      return typeof this.item === 'object' ? 1 : (typeof this.item === 'string' ? -1 : 0)
    }
  },
  mounted() {
    this.fetchData()
  },
  watch: {
    '$route'({ name }) {
      if (name === 'MailConfig') this.fetchData()
    }
  },
  methods: {
    fetchData(page = 1) {
      this.page = page
      return MailConfigProvider.find(undefined, { page: this.page, recordsPerPage: this.recordsPerPage }).then(data => this.list = data)
    },
    openUpdate(item = { name: undefined, config: { host: undefined, port: undefined, secure: false, auth: { user: undefined, pass: undefined } } }) {
      this.item = _.cloneDeep(item)
    },
    closeUpdate(type) {
      this.item = undefined
      if (type) this.$pub('msg', { type: 1, msg: `${type} successfully` })
    },
    test() {
      if (!this.item.to) return
      this.$validator.validateAll().then((isValid) => {
        if (isValid) {
          this.isTesting = true
          MailConfigProvider.test(this.item).then(rs => {
            this.isTesting = false
            this.$pub('msg', { type: 1, msg: `Sent an email to "${this.item.to}" successfully` })
          }).catch(() => {
            this.isTesting = false
          })
        }
      })
    },
    save() {
      this.$validator.validateAll().then((isValid) => {
        if (isValid) {
          if (!this.item._id) {
            MailConfigProvider.insert(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Added')))
          } else {
            MailConfigProvider.update(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Updated')))
          }
        }
      })
    },
    remove() {
      MailConfigProvider.delete(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Deleted')))
    }
  }
}
</script> 
