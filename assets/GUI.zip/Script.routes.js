import { URL } from '@/providers/Script.provider'

export default [
  { path: '/Script', name: 'Script', component: require('@/components/Script'), gicon: 'fa-file-code-o', icon: 'fa-terminal', group: 'Script', link: URL }
]
