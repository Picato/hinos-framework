import { URL } from '@/providers/Script.provider'

export default [
  { path: '/Script', name: 'Script', component: require('@/components/Script'), icon: 'fa-terminal', group: 'Script', link: URL }
]
