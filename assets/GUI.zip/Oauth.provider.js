import axios from 'axios'
import AppConfig from '@/AppConfig'

export const URL = '${url}'

export const ProjectProvider = {
  get() {
    return axios.get(`${URL}/Project`).then(resp => resp.data)
  },
  find(where, opts = { page: 1, recordsPerPage: 1 }) {
    return axios.get(`${URL}/Projects`, {
      params: opts
    }).then(resp => resp.data)
  },
  insert(item) {
    return axios.post(`${URL}/Project`, item).then(resp => resp.data)
  },
  update(item) {
    return axios.put(`${URL}/Project/${item._id}`, item).then(resp => resp.data)
  },
  updateMine(item) {
    return axios.put(`${URL}/Project`, item).then(resp => resp.data)
  },
  delete(_id) {
    return axios.delete(`${URL}/Project/${_id}`).then(resp => resp.data)
  }
}

export const RoleProvider = {
  find(where, opts = { page: 1, recordsPerPage: 0 }) {
    return axios.get(`${URL}/Role`, {
      params: opts
    }).then(resp => resp.data)
  },
  insert(item) {
    return axios.post(`${URL}/Role`, item).then(resp => resp.data)
  },
  update(item) {
    return axios.put(`${URL}/Role/${item._id}`, item).then(resp => resp.data)
  },
  delete(_id) {
    return axios.delete(`${URL}/Role/${_id}`).then(resp => resp.data)
  }
}

export const AccountProvider = {
  login(user, pj) {
    if (pj) {
      return axios.post(`${URL}/Login`, user, {
        headers: {
          pj
        }
      }).then(resp => {
        const token = resp.headers.token
        localStorage.setItem('token', token)
        axios.defaults.headers.common['token'] = token
        this.ping(true)
        return this.getMyRoles().then(roles => {
          return ProjectProvider.get().then(prj => {
            AppConfig.opts.project = {
              _id: prj._id,
              name: prj.name,
              des: prj.des,
              admin: user.username,
              roles
            }
            localStorage.setItem('project', JSON.stringify(AppConfig.opts.project))
            return token
          })
        })
      })
    }
    return new Promise((resolve) => {
      const token = user
      AppConfig.opts.project = {
        name: 'Super Project',
        des: 'Project of all systems',
        roles: [{ '.*': '.*' }]
      }
      localStorage.setItem('project', JSON.stringify(AppConfig.opts.project))
      localStorage.setItem('token', token)
      axios.defaults.headers.common['token'] = token
      resolve(token)
    })
  },
  logout() {
    return axios.get(`${URL}/Logout`).then(resp => {
      localStorage.clear()
      delete axios.defaults.headers.common['token']
    })
  },
  find(where, opts = { page: 1, recordsPerPage: 1 }) {
    return axios.get(`${URL}/Account`, {
      params: opts
    }).then(resp => resp.data)
  },
  insert(item) {
    return axios.post(`${URL}/Account`, item).then(resp => resp.data)
  },
  update(item) {
    return axios.put(`${URL}/Account/${item._id}`, item).then(resp => resp.data)
  },
  delete(_id) {
    return axios.delete(`${URL}/Account/${_id}`).then(resp => resp.data)
  },
  generateKey(isAdd) {
    if (isAdd) return axios.put(`${URL}/Secretkey`).then(resp => resp.data)
    return axios.delete(`${URL}/Secretkey`).then(resp => resp.data)
  },
  getMyRoles() {
    return axios.get(`${URL}/MyRoles?type=web`).then(resp => resp.data)
  },
  ping(isLater) {
    if (axios.defaults.headers.common['token']) {
      if (isLater) {
        setTimeout(this.ping, +axios.defaults.headers.common['token'].split('?')[1] * 1000 - 30000)
      } else {
        axios.head(`${URL}/Ping`).then(() => {
          setTimeout(this.ping, +axios.defaults.headers.common['token'].split('?')[1] * 1000 - 30000)
        })
      }
    }
  }
}
