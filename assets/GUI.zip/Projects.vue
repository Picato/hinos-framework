<template>
  <Page title="Projects management" subtitle="Manage Projects in company" :breadcrumb="['Super Admin', 'Projects']">
    <template slot="others">
      <ConfirmComponent :show="action === -1" title="Do you want to delete it ?" @yes="remove()" @no="item=undefined"></ConfirmComponent>
      <PopupComponent title="User Form" :show="action === 1">
        <template slot="body" v-if="item">
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">name *</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <input class="input" :class="{'is-danger': errors.has('name')}" type="text" placeholder="name" v-model.trim="item.name" name="name" v-validate="'required'">
                </p>
                <p class="help is-danger" v-show="errors.has('name')">{{ errors.first('name') }}</p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">des</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <input class="input" type="text" placeholder="des" v-model.trim="item.des" name="des">
                </p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">status *</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <span class="select" :class="{'is-danger': errors.has('status')}">
                    <select v-model.trim="item.status" name="status" v-validate="'required'">
                      <option :value="1">Active</option>
                      <option :value="0">Inactive</option>
                    </select>
                  </span>
                </p>
                <p class="help is-danger" v-show="errors.has('status')">{{ errors.first('status') }}</p>
              </div>
              <div class="field">
                <p class="control">
                  <input class="input has-text-right" type="text" :value="item.owner" disabled>
                </p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Plugins Configuration</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <textarea class="textarea" v-model="item.plugins" name="plugins" v-validate="item._id ? 'required' : ''" :class="{'is-danger': errors.has('plugins')}" :placeholder="!item._id ? 'It will be auto generate' : ''" :disabled="!item._id"></textarea>
                </p>
                <p class="help is-danger" v-show="errors.has('plugins')">{{ errors.first('plugins') }}</p>
              </div>
            </div>
          </div>
        </template>
        <template slot="footer" v-if="item">
          <a class="button is-primary" @click="save()" ref="submit">
            <span class="icon">
              <i class="fa fa-floppy-o"></i>
            </span>
            <span>Save changes</span>
          </a>
          <a class="button" @click="closeUpdate()">
            <span class="icon">
              <i class="fa fa-times"></i>
            </span>
            <span>Cancel</span>
          </a>
        </template>
      </PopupComponent>
    </template>
    <template slot="main">
      <TableComponent>
        <template slot="pagination" v-if="list">
          <a class="pagination-previous" title="This is the first page" @click="page <= 1 ? null : fetchData(page - 1)" :disabled="page <= 1">Previous</a>
          <a class="pagination-next" @click="list.length < recordsPerPage ? null : fetchData(page + 1)" :disabled="list.length < recordsPerPage">Next page</a>
          <ul class="pagination-list">
            <li>
              <div class="field has-addons">
                <p class="control">
                  <a class="button is-static">
                    Page {{page}}
                  </a>
                </p>
                <p class="control">
                  <span class="select">
                    <select v-model="recordsPerPage" @change="fetchData(1)">
                      <option :value="20">Show 20 records</option>
                      <option :value="50">Show 50 records</option>
                      <option :value="100">Show 100 records</option>
                    </select>
                  </span>
                </p>
              </div>
            </li>
          </ul>
        </template>
        <template slot="head">
          <tr>
            <th width="1">#</th>
            <th>name</th>
            <th>des</th>
            <th>status</th>
            <th>created_at</th>
            <th width="1">
              <a class="button is-primary is-small" v-on:click="openUpdate()">
                <span class="icon is-small">
                  <i class="fa fa-plus-square-o"></i>
                </span>
                <span>Add</span>
              </a>
            </th>
          </tr>
        </template>
        <template slot="body" v-if="list">
          <tr v-for="(e, i) in list" :key="e._id">
            <th>{{(page - 1) * recordsPerPage + i + 1}}</th>
            <td>
              <a @click="goToLogin(e._id)">{{ e.name }}</a>
              <span class="tag">{{ e._id }}</span>
            </td>
            <td>{{ e.des }}</td>
            <td>
              <span class="tag" :class="{'is-success': e.status === 1, 'is-danger': e.status === 0}">{{ e.status | $status}}</span>
            </td>
            <td>{{ e.created_at | $date('DD/MM/YYYY hh:mm') }}</td>
            <td>
              <div class="field has-addons">
                <p class="control">
                  <a class="button is-small" @click="openUpdate(e)">
                    <span class="icon is-small">
                      <i class="fa fa-pencil-square-o"></i>
                    </span>
                    <span>Edit</span>
                  </a>
                </p>
                <p class="control">
                  <a class="button is-small" @click="item=e._id">
                    <span class="icon is-small">
                      <i class="fa fa-trash-o"></i>
                    </span>
                    <span>Delete</span>
                  </a>
                </p>
              </div>
            </td>
          </tr>
        </template>
      </TableComponent>
    </template>
  </Page>
</template>
</template>

<script>
import _ from 'lodash'
import { $find, $show, $date } from '@/filters/Core'
import Page from '@/components/template/Page'
import PopupComponent from '@/components/common/Popup.component'
import TableComponent from '@/components/common/Table.component'
import ConfirmComponent from '@/components/common/Confirm.component'
import ProjectProvider from '@/providers/Project.provider'

export default {
  name: 'list',
  filters: {
    $find,
    $show,
    $date,
    $status(value) {
      return value === 0 ? 'INACTIVE' : 'ACTIVED'
    }
  },
  components: { PopupComponent, ConfirmComponent, Page, TableComponent },
  data() {
    return {
      page: 1,
      recordsPerPage: 20,
      item: undefined,
      list: undefined
    }
  },
  computed: {
    action() {
      return typeof this.item === 'object' ? 1 : (typeof this.item === 'string' ? -1 : 0)
    }
  },
  mounted() {
    this.fetchData()
  },
  methods: {
    fetchData(page = 1) {
      this.page = page
      return ProjectProvider.find(undefined, { page: this.page, recordsPerPage: this.recordsPerPage }).then(data => this.list = data)
    },
    openUpdate(item = { status: 1 }) {
      let tmpPlugins = item.plugins
      this.item = _.cloneDeep(item)
      Object.defineProperty(this.item, 'plugins', {
        get() {
          return JSON.stringify(tmpPlugins, null, '    ')
        },
        set(vl) {
          if (!vl) return undefined
          tmpPlugins = typeof vl === 'object' ? vl : JSON.parse(tmpPlugins)
        }
      })
    },
    closeUpdate(type) {
      this.item = undefined
      if (type) this.$pub('msg', { type: 1, msg: `${type} successfully` })
    },
    goToLogin(_id) {
      this.$router.push(`/Login?pj=${_id}`)
    },
    save() {
      this.$validator.validateAll().then((isValid) => {
        if (isValid) {
          if (!this.item._id) {
            ProjectProvider.insert(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Added')))
          } else {
            ProjectProvider.update(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Updated')))
          }
        }
      })
    },
    remove() {
      ProjectProvider.delete(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Deleted')))
    }
  }
}
</script> 
