import axios from 'axios'

export default {
  url: '${url}',
  find(where, opts = { page: 1, recordsPerPage: 1 }) {
    return axios.get(`${this.url}/Config`, {
      params: opts
    }).then(resp => resp.data)
  },
  insert(item) {
    return axios.post(`${this.url}/Config`, item).then(resp => resp.data)
  },
  update(item) {
    return axios.put(`${this.url}/Config/${item._id}`, item).then(resp => resp.data)
  },
  delete(_id) {
    return axios.delete(`${this.url}/Config/${_id}`).then(resp => resp.data)
  }
}
