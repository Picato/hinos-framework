import axios from 'axios'
import ProjectProvider from '@/providers/Project.provider'

export default {
  url: ProjectProvider.url,
  find(where, opts = { page: 1, recordsPerPage: 0 }) {
    return axios.get(`${this.url}/Role`, {
      params: opts
    }).then(resp => resp.data)
  },
  insert(item) {
    return axios.post(`${this.url}/Role`, item).then(resp => resp.data)
  },
  update(item) {
    return axios.put(`${this.url}/Role/${item._id}`, item).then(resp => resp.data)
  },
  delete(_id) {
    return axios.delete(`${this.url}/Role/${_id}`).then(resp => resp.data)
  }
}
