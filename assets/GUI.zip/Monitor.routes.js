import { URL } from '@/providers/Monitor.provider'

export default [
  { path: '/monitor', name: 'Monitor', component: require('@/components/Monitor'), gicon: 'fa-desktop', icon: 'fa-desktop', group: 'Monitor services', link: URL }
]
