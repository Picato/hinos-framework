import MonitorProvider from '@/providers/Monitor.provider'

export default [
  { path: '/monitor', name: 'Monitor', component: require('@/components/Monitor'), icon: 'fa-info', group: 'Monitor services', link: MonitorProvider.url }
]
