import axios from 'axios'

export default {
  url: '${url}',
  findService(where, opts = { page: 1, recordsPerPage: 20 }) {
    return axios.get(`${this.url}/Service`, {
      params: opts
    }).then(resp => resp.data)
  },
  getService(item) {
    return axios.get(`${this.url}/Service/${item._id}`, item).then(resp => resp.data)
  },
  insertService(item) {
    return axios.post(`${this.url}/Service`, item).then(resp => resp.data)
  },
  deleteService(_id) {
    return axios.delete(`${this.url}/Service/${_id}`).then(resp => resp.data)
  },
  getApis(link) {
    return axios.get(`${link}/Routes`).then(resp => resp.data)
  }
}
