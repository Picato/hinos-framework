import axios from 'axios'

export const URL = '${url}'

export const GatewayProvider = {
  findService(where, opts = { page: 1, recordsPerPage: 20 }) {
    return axios.get(`${URL}/Service`, {
      params: opts
    }).then(resp => resp.data)
  },
  getService(item) {
    return axios.get(`${URL}/Service/${item._id}`, item).then(resp => resp.data)
  },
  insertService(item) {
    return axios.put(`${URL}/Service`, item).then(resp => resp.data)
  },
  deleteService(_id) {
    return axios.delete(`${URL}/Service/${_id}`).then(resp => resp.data)
  },
  getApis(link) {
    return axios.get(`${link}/Routes`).then(resp => resp.data)
  }
}
