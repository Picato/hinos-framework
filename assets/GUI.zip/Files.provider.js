import axios from 'axios'

export const URL = '${url}'

export const FilesProvider = {
  store(files) {
    return axios.put(`${URL}/Store`, { files }).then(resp => resp.data)
  },
  find(where, opts = { page: 1, recordsPerPage: 1 }) {
    return axios.get(`${URL}`, {
      params: opts
    }).then(resp => resp.data)
  },
  upload(item, configId) {
    return axios.post(`${URL}/Upload/${configId}`, item).then(resp => resp.data)
  },
  delete(files) {
    return axios.put(`${URL}/Remove`, { files }).then(resp => resp.data)
  }
}

export const FileConfigProvider = {
  find(where, opts = { page: 1, recordsPerPage: 1 }) {
    return axios.get(`${URL}/Config`, {
      params: opts
    }).then(resp => resp.data)
  },
  insert(item) {
    return axios.post(`${URL}/Config`, item).then(resp => resp.data)
  },
  update(item) {
    return axios.put(`${URL}/Config/${item._id}`, item).then(resp => resp.data)
  },
  delete(_id) {
    return axios.delete(`${URL}/Config/${_id}`).then(resp => resp.data)
  }
}
