import axios from 'axios'
import FileConfigProvider from './FileConfig.provider'

export default {
  url: FileConfigProvider.url,
  store(files) {
    return axios.put(`${this.url}/Files/Store`, { files }).then(resp => resp.data)
  },
  find(where, opts = { page: 1, recordsPerPage: 1 }) {
    return axios.get(`${this.url}`, {
      params: opts
    }).then(resp => resp.data)
  },
  upload(item, configId) {
    return axios.post(`${this.url}/Files/Upload/${configId}`, item).then(resp => resp.data)
  },
  delete(files) {
    return axios.put(`${this.url}/Files/Remove`, { files }).then(resp => resp.data)
  }
}
