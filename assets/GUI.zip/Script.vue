<template>
  <Page title="Script management" subtitle="Manage Script in project" :breadcrumb="['Script service', 'Script']">
    <template slot="others">
      <ConfirmComponent :show="action === -1" title="Do you want to delete it ?" @yes="remove()" @no="item=undefined"></ConfirmComponent>
      <PopupComponent title="Script Form" :show="action === 1" size="large">
        <template slot="body" v-if="item">
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Name *</label>
            </div>
            <div class="field-body">
              <div class="columns" style="width:100%">
                <div class="field column">
                  <div class="field has-addons">
                    <p class="control is-expanded">
                      <input class="input" :class="{'is-danger': errors.has('name')}" type="text" placeholder="name" v-model.trim="item.name" name="name" v-validate="'required'">
                    </p>
                    <p class="control">
                      <span class="select">
                        <select v-model.trim="item.ext">
                          <option value="sh">.sh</option>
                          <option value="bat">.bat</option>
                        </select>
                      </span>
                    </p>
                  </div>
                  <p class="help is-danger" v-show="errors.has('name')">{{ errors.first('name') }}</p>
                </div>
                <div class="field column is-one-quarter">
                  <div class="control">
                    <div class="select">
                      <select v-model="item.is_private" :class="{'has-text-danger': item.is_private, 'has-text-success': !item.is_private}">
                        <option :value="false" class="has-text-success">Shared</option>
                        <option :value="true" class="has-text-danger">Private</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Content *</label>
              <span class="tag is-small" v-show="sugScript" v-for="s in item.sugScripts" :key="s._id">{{s.name}}</span>
            </div>
            <div class="field-body">
              <div class="columns" style="margin-bottom: 0px; width:100%">
                <div class="field column">
                  <p class="control">
                    <textarea rows="10" ref="content" class="textarea" :class="{'is-danger': errors.has('content')}" type="text" placeholder="content" v-model.trim="item.content" @keydown="suggest" name="content" v-validate="'required'"></textarea>
                  </p>
                  <p class="help is-danger" v-show="errors.has('content')">{{ errors.first('content') }}</p>
                </div>
                <div class="field column is-one-quarter">
                  <p class="control">
                    <textarea rows="10" ref="des" class="textarea" type="text" placeholder="Description" v-model.trim="item.des" name="des"></textarea>
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Tag</label>
            </div>
            <div class="field-body" style="display: block">
              <div class="columns" style="margin-bottom: 0px;">
                <div class="field column">
                  <p class="control">
                    <input class="input" :class="{'is-danger': errors.has('tag')}" type="text" placeholder="tag" v-model.trim="item.tag" name="tag" v-validate="'required'">
                  </p>
                  <p class="help is-danger" v-show="errors.has('tag')">{{ errors.first('tag') }}</p>
                </div>
              </div>
              <div class="tags" v-if="this.item.tag">
                <span class="tag" v-for="t of this.item.tag.split(',').map(e => e.trim()).filter(e => e.trim().length > 0)" :key="t">{{t}}</span>
              </div>
            </div>
          </div>
        </template>
        <template slot="footer" v-if="item">
          <a class="button is-success" @click="save()">
            <span class="icon">
              <i class="fa fa-floppy-o"></i>
            </span>
            <span>Save changes</span>
          </a>
          <a class="button" @click="closeUpdate()">
            <span class="icon">
              <i class="fa fa-times"></i>
            </span>
            <span>Cancel</span>
          </a>
        </template>
      </PopupComponent>
    </template>
    <template slot="main">
      <TableComponent>
        <template slot="pagination" v-if="list">
          <a class="pagination-previous" title="This is the first page" @click="page <= 1 ? null : fetchData(page - 1)" :disabled="page <= 1">Previous</a>
          <a class="pagination-next" @click="list.length < recordsPerPage ? null : fetchData(page + 1)" :disabled="list.length < recordsPerPage">Next page</a>
          <ul class="pagination-list">
            <li>
              <div class="field has-addons">
                <p class="control">
                  <a class="button is-static">
                    Page {{page}}
                  </a>
                </p>
                <p class="control">
                  <span class="select">
                    <select v-model="recordsPerPage" @change="fetchData(1)">
                      <option :value="20">Show 20 records</option>
                      <option :value="50">Show 50 records</option>
                      <option :value="100">Show 100 records</option>
                    </select>
                  </span>
                </p>
                &nbsp;&nbsp;&nbsp;
                <form class="field has-addons" v-permission:allow.SEARCH @submit.prevent="fetchData()">
                  <div class="control">
                    <input class="input" type="text" v-model="txtName" placeholder="Search here">
                  </div>
                  <div class="control">
                    <button type="submit" class="button is-primary">
                      Search by tag
                    </button>
                  </div>
                </form>
              </div>
            </li>
          </ul>
        </template>
        <template slot="head">
          <tr>
            <th width="1">#</th>
            <th width="300">name</th>
            <th>tag</th>
            <th width="1">
              <a class="button is-primary is-small" v-on:click="openUpdate()" v-permission:allow.ADD>
                <span class="icon is-small">
                  <i class="fa fa-plus-square-o"></i>
                </span>
                <span>Add</span>
              </a>
            </th>
          </tr>
        </template>
        <template slot="body" v-if="list">
          <tr v-for="(e, i) in list" :key="e._id">
            <th>{{(page - 1) * recordsPerPage + i + 1}}</th>
            <td :class="{'has-text-danger': e.is_private, 'has-text-success': !e.is_private}" :title="e.is_private? 'Private': 'Public'">{{ e.name }}</td>
            <td>
              <span class="tag" :class="{'is-success': t === txtName}" style="margin: 0px 2px" v-for="t in e.tag" :key="t">{{t}}</span>
            </td>
            <td>
              <div class="field has-addons">
                <p class="control">
                  <span class="select is-small is-primary">
                    <select v-model="e.copyType">
                      <option :value="undefined">link</option>
                      <option value="wget">wget</option>
                      <option value="curl">curl</option>
                    </select>
                  </span>
                </p>
                <p class="control">
                  <a class="button is-small is-primary" v-permission:allow.SEARCH @click="copyToClipboard(e, i)">
                    <span class="icon is-small">
                      <i class="fa fa-copy" v-if="!e.copied"></i>
                      <i class="fa fa-clipboard" v-if="e.copied"></i>
                    </span>
                    <span v-if="!e.copied">Copy</span>
                    <span v-if="e.copied">Copied</span>
                  </a>
                </p>
                <p class="control" v-if="e.project_id === curProjectId">
                  <a class="button is-small is-info" @click="openUpdate(e)" v-permission:allow.EDIT>
                    <span class="icon is-small">
                      <i class="fa fa-pencil-square-o"></i>
                    </span>
                    <span>Edit</span>
                  </a>
                </p>
                <p class="control" v-if="e.project_id === curProjectId">
                  <a class="button is-small is-dark" @click="item=e._id" v-permission:allow.DELETE>
                    <span class="icon is-small">
                      <i class="fa fa-trash-o"></i>
                    </span>
                    <span>Delete</span>
                  </a>
                </p>
              </div>
            </td>
          </tr>
        </template>
      </TableComponent>
    </template>
  </Page>
</template>

<script>
import _ from 'lodash'
import { $find, $show, $date } from '@/filters/Core'
import AppConfig from '@/AppConfig'
import Page from '@/components/template/Page'
import PopupComponent from '@/components/common/Popup.component'
import TableComponent from '@/components/common/Table.component'
import ConfirmComponent from '@/components/common/Confirm.component'
import { ScriptProvider } from '@/providers/Script.provider'
import clipboard from 'clipboard-js'

export default {
  name: 'list',
  filters: { $find, $show, $date },
  components: { PopupComponent, ConfirmComponent, Page, TableComponent },
  data() {
    return {
      curProjectId: AppConfig.opts.project._id,
      page: 1,
      recordsPerPage: 20,
      item: undefined,
      list: undefined,
      sugScript: undefined,
      tm: undefined,
      txtName: undefined
    }
  },
  computed: {
    action() {
      return typeof this.item === 'object' ? 1 : (typeof this.item === 'string' ? -1 : 0)
    }
  },
  mounted() {
    this.fetchData(1)
  },
  methods: {
    getDownloadLink: ScriptProvider.getDownloadLink,
    suggest(evt) {
      if (['Alt', 'Ctrl', 'Shift'].includes(evt.key)) return
      if (evt.key === '@') {
        this.sugScript = '@'
      } else if (this.sugScript !== undefined) {
        if (evt.key === ' ' || evt.key === 'Enter') {
          this.sugScript = undefined
          return
        } else if (evt.key === 'Backspace') {
          this.sugScript = this.sugScript.substr(0, this.sugScript.length - 1)
          if (this.sugScript.length === 0) {
            this.sugScript = undefined
          } else if (this.sugScript.length === 1) {
            this.item = Object.assign({}, this.item, { sugScripts: [] })
          }
        } else {
          this.sugScript += evt.key
          if (this.tm) clearTimeout(this.tm)
          const self = this
          this.tm = setTimeout(() => {
            ScriptProvider.find({ tag: self.sugScript.substr(1) }).then(data => {
              this.item = Object.assign({}, this.item, { sugScripts: data })
            })
          }, 500)
        }
      }
    },
    copyToClipboard(e, i) {
      const dllink = this.getDownloadLink(e)
      this.$set(this.list[i], 'copied', true)
      if (e.copyType === 'wget') clipboard.copy(`wget "${dllink}" -O "${e.name}.${e.ext}"`)
      else if (e.copyType === 'curl') clipboard.copy(`curl -o "${e.name}.${e.ext}" "${dllink}"`)
      else clipboard.copy(dllink)

      setTimeout(() => {
        this.$delete(this.list[i], 'copied')
      }, 1000)
    },
    fetchData(page = 1) {
      this.page = page
      return ScriptProvider.find(this.txtName ? { tag: this.txtName } : {}, { page: this.page, recordsPerPage: this.recordsPerPage }).then(data => this.list = data)
    },
    openUpdate(item = { ext: 'sh', is_private: false }) {
      if (item._id) {
        ScriptProvider.get(item).then(item => {
          this.item = _.cloneDeep(item)
          if (this.item.tag) this.item.tag = this.item.tag.join(', ')
          this.item.sugScripts = []
        })
      } else {
        this.item = _.cloneDeep(item)
        this.item.sugScripts = []
      }
    },
    closeUpdate(type) {
      this.item = undefined
      if (type) this.$pub('msg', { type: 1, msg: `${type} successfully` })
    },
    save() {
      this.$validator.validateAll().then((isValid) => {
        if (isValid) {
          if (!this.item._id) {
            ScriptProvider.insert(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Added')))
          } else {
            ScriptProvider.update(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Updated')))
          }
        }
      })
    },
    remove() {
      ScriptProvider.delete(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Deleted')))
    }
  }
}
</script> 
