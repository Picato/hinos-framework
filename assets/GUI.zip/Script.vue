<template>
  <Page title="Script management" subtitle="Manage Script in project" :breadcrumb="['APIs', 'Script']">
    <template slot="others">
      <ConfirmComponent :show="action === -1" title="Do you want to delete it ?" @yes="remove()" @no="item=undefined"></ConfirmComponent>
      <PopupComponent title="Script Form" :show="action === 1">
        <template slot="body" v-if="item">
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Name *</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <input class="input" :class="{'is-danger': errors.has('name')}" type="text" placeholder="name" v-model.trim="item.name" name="name" v-validate="'required'">
                </p>
                <p class="help is-danger" v-show="errors.has('name')">{{ errors.first('name') }}</p>
              </div>
              <div class="field">
                <p class="control">
                  <input class="input" :class="{'is-danger': errors.has('ext')}" type="text" placeholder="extension" v-model.trim="item.ext" name="ext" v-validate="'required'">
                </p>
                <p class="help is-danger" v-show="errors.has('ext')">{{ errors.first('ext') }}</p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">content *</label>
              <span class="tag is-small" v-show="sugScript" v-for="s in item.sugScripts" :key="s._id">{{s.name}}</span>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <textarea ref="content" class="textarea" :class="{'is-danger': errors.has('content')}" type="text" placeholder="content" v-model.trim="item.content" @keydown="suggest" name="content" v-validate="'required'"></textarea>
                </p>
                <p class="help is-danger" v-show="errors.has('content')">{{ errors.first('content') }}</p>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">tag *</label>
            </div>
            <div class="field-body">
              <div class="field">
                <p class="control">
                  <input class="input" :class="{'is-danger': errors.has('tag')}" type="text" placeholder="tag" v-model.trim="item.tag" name="tag" v-validate="'required'">
                </p>
                <p class="help is-danger" v-show="errors.has('tag')">{{ errors.first('tag') }}</p>
              </div>
              <div class="field">
                <div class="control">
                  <label class="checkbox" :class="{'has-text-danger': item.is_private, 'has-text-success': !item.is_private}">
                    <input type="checkbox" v-model="item.is_private"> {{item.is_private ? 'Private' : 'Shared'}}
                  </label>
                </div>
              </div>
            </div>
          </div>
        </template>
        <template slot="footer" v-if="item">
          <a class="button is-success" @click="save()">
            <span class="icon">
              <i class="fa fa-floppy-o"></i>
            </span>
            <span>Save changes</span>
          </a>
          <a class="button" @click="closeUpdate()">
            <span class="icon">
              <i class="fa fa-times"></i>
            </span>
            <span>Cancel</span>
          </a>
        </template>
      </PopupComponent>
    </template>
    <template slot="main">
      <TableComponent>
        <template slot="pagination" v-if="list">
          <a class="pagination-previous" title="This is the first page" @click="page <= 1 ? null : fetchData(page - 1)" :disabled="page <= 1">Previous</a>
          <a class="pagination-next" @click="list.length < recordsPerPage ? null : fetchData(page + 1)" :disabled="list.length < recordsPerPage">Next page</a>
          <ul class="pagination-list">
            <li>
              <div class="field has-addons">
                <p class="control">
                  <a class="button is-static">
                    Page {{page}}
                  </a>
                </p>
                <p class="control">
                  <span class="select">
                    <select v-model="recordsPerPage" @change="fetchData(1)">
                      <option :value="20">Show 20 records</option>
                      <option :value="50">Show 50 records</option>
                      <option :value="100">Show 100 records</option>
                    </select>
                  </span>
                </p>
                &nbsp;&nbsp;&nbsp;
                <form class="field has-addons" v-permission:allow.SEARCH @submit.prevent="fetchData()">
                  <div class="control">
                    <input class="input" type="text" v-model="txtName" placeholder="Search here">
                  </div>
                  <div class="control">
                    <button type="submit" class="button is-primary">
                      Search by tag
                    </button>
                  </div>
                </form>
              </div>
            </li>
          </ul>
        </template>
        <template slot="head">
          <tr>
            <th width="1">#</th>
            <th>name</th>
            <th width="1">Status</th>
            <th>tag</th>
            <th width="1">
              <a class="button is-primary is-small" v-on:click="openUpdate()" v-permission:allow.ADD>
                <span class="icon is-small">
                  <i class="fa fa-plus-square-o"></i>
                </span>
                <span>Add</span>
              </a>
            </th>
          </tr>
        </template>
        <template slot="body" v-if="list">
          <tr v-for="(e, i) in list" :key="e._id">
            <th>{{(page - 1) * recordsPerPage + i + 1}}</th>
            <td> {{ e.name }}</td>
            <td>
              <span v-if="!e.is_private" class="tag is-success">Public</span>
              <span v-if="e.is_private" class="tag is-danger">Private</span>
            </td>
            <td>
              <span class="tag" :class="{'is-success': t === txtName}" style="margin: 0px 2px" v-for="t in e.tag" :key="t">{{t}}</span>
            </td>
            <td>
              <div class="field has-addons">
                <p class="control">
                  <a class="button is-small is-primary" :href="getDownloadLink(e)" v-permission:allow.SEARCH>
                    <span class="icon is-small">
                      <i class="fa fa-share-alt"></i>
                    </span>
                    <span>Get link</span>
                  </a>
                </p>
                <p class="control">
                  <a class="button is-small is-info" @click="openUpdate(e)" v-permission:allow.EDIT>
                    <span class="icon is-small">
                      <i class="fa fa-pencil-square-o"></i>
                    </span>
                    <span>Edit</span>
                  </a>
                </p>
                <p class="control">
                  <a class="button is-small is-dark" @click="item=e._id" v-permission:allow.DELETE>
                    <span class="icon is-small">
                      <i class="fa fa-trash-o"></i>
                    </span>
                    <span>Delete</span>
                  </a>
                </p>
              </div>
            </td>
          </tr>
        </template>
      </TableComponent>
    </template>
  </Page>
</template>

<script>
import _ from 'lodash'
import { $find, $show, $date } from '@/filters/Core'
import Page from '@/components/template/Page'
import PopupComponent from '@/components/common/Popup.component'
import TableComponent from '@/components/common/Table.component'
import ConfirmComponent from '@/components/common/Confirm.component'
import { ScriptProvider } from '@/providers/Script.provider'

export default {
  name: 'list',
  filters: { $find, $show, $date },
  components: { PopupComponent, ConfirmComponent, Page, TableComponent },
  data() {
    return {
      page: 1,
      recordsPerPage: 20,
      item: undefined,
      list: undefined,
      sugScript: undefined,
      tm: undefined,
      txtName: undefined
    }
  },
  computed: {
    action() {
      return typeof this.item === 'object' ? 1 : (typeof this.item === 'string' ? -1 : 0)
    }
  },
  mounted() {
    this.fetchData(1)
  },
  methods: {
    getDownloadLink: ScriptProvider.getDownloadLink,
    suggest(evt) {
      if (['Alt', 'Ctrl', 'Shift'].includes(evt.key)) return
      if (evt.key === '@') {
        this.sugScript = '@'
      } else if (this.sugScript !== undefined) {
        if (evt.key === ' ' || evt.key === 'Enter') {
          this.sugScript = undefined
          return
        } else if (evt.key === 'Backspace') {
          this.sugScript = this.sugScript.substr(0, this.sugScript.length - 1)
          if (this.sugScript.length === 0) {
            this.sugScript = undefined
          } else if (this.sugScript.length === 1) {
            this.item = Object.assign({}, this.item, { sugScripts: [] })
          }
        } else {
          this.sugScript += evt.key
          if (this.tm) clearTimeout(this.tm)
          const self = this
          this.tm = setTimeout(() => {
            ScriptProvider.find(`?tag=${self.sugScript.substr(1)}`).then(data => {
              this.item = Object.assign({}, this.item, { sugScripts: data })
            })
          }, 500)
        }
      }
    },
    fetchData(page = 1) {
      this.page = page
      return ScriptProvider.find(this.txtName ? `?tag=${this.txtName}` : undefined, { page: this.page, recordsPerPage: this.recordsPerPage }).then(data => this.list = data)
    },
    openUpdate(item = { ext: 'sh', is_private: true }) {
      if (item._id) {
        ScriptProvider.get(item).then(item => {
          this.item = _.cloneDeep(item)
          if (this.item.tag) this.item.tag = this.item.tag.join(', ')
          this.item.sugScripts = []
        })
      } else {
        this.item = _.cloneDeep(item)
        this.item.sugScripts = []
      }
    },
    closeUpdate(type) {
      this.item = undefined
      if (type) this.$pub('msg', { type: 1, msg: `${type} successfully` })
    },
    save() {
      this.$validator.validateAll().then((isValid) => {
        if (isValid) {
          if (!this.item._id) {
            ScriptProvider.insert(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Added')))
          } else {
            ScriptProvider.update(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Updated')))
          }
        }
      })
    },
    remove() {
      ScriptProvider.delete(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Deleted')))
    }
  }
}
</script> 
