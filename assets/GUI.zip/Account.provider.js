import axios from 'axios'
import AppConfig from '@/AppConfig'
import ProjectProvider from '@/providers/Project.provider'

export default {
  url: ProjectProvider.url,
  login(user, pj) {
    if (pj) {
      return axios.post(`${this.url}/Login`, user, {
        headers: {
          pj
        }
      }).then(resp => {
        const token = resp.headers.token
        localStorage.setItem('token', token)
        axios.defaults.headers.common['token'] = token
        return ProjectProvider.get().then(prj => {
          AppConfig.opts.project = {
            _id: prj._id,
            name: prj.name,
            des: prj.des,
            admin: user.username
          }
          localStorage.setItem('project', JSON.stringify(AppConfig.opts.project))
          return token
        })
      })
    }
    return new Promise((resolve) => {
      const token = user
      AppConfig.opts.project = {
        name: 'Super Project',
        des: 'Project of all systems'
      }
      localStorage.setItem('project', JSON.stringify(AppConfig.opts.project))
      localStorage.setItem('token', token)
      axios.defaults.headers.common['token'] = token
      resolve(token)
    })
  },
  logout() {
    return axios.get(`${this.url}/Logout`).then(resp => {
      localStorage.clear()
      delete axios.defaults.headers.common['token']
    })
  },
  find(where, opts = { page: 1, recordsPerPage: 1 }) {
    return axios.get(`${this.url}/Account`, {
      params: opts
    }).then(resp => resp.data)
  },
  insert(item) {
    return axios.post(`${this.url}/Account`, item).then(resp => resp.data)
  },
  update(item) {
    return axios.put(`${this.url}/Account/${item._id}`, item).then(resp => resp.data)
  },
  delete(_id) {
    return axios.delete(`${this.url}/Account/${_id}`).then(resp => resp.data)
  },
  generateKey(isAdd) {
    if (isAdd) return axios.put(`${this.url}/Secretkey`).then(resp => resp.data)
    return axios.delete(`${this.url}/Secretkey`).then(resp => resp.data)
  },
  ping() {
    if (axios.defaults.headers.common['token']) {
      axios.head(`${this.url}/Ping`).then(() => {
        setTimeout(this.ping, +axios.defaults.headers.common['token'].split('?')[1] * 1000 - 10000)
      })
    }
  }
}
