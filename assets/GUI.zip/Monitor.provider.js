import axios from 'axios'
import socketio from 'socket.io-client'

export const URL = '${url}'

export const MonitorProvider = {
  listen(cb) {
    return axios.get(`${URL}/WSSession`).then(resp => resp.data).then(session => {
      const io = socketio(URL.substr(0, URL.lastIndexOf('/')) + '/msg', {
        transports: ['websocket'],
        query: {
          name: 'Monitor'
        }
      })
      io.emit('register', session)
      io.on(session, (data) => {
        cb(JSON.parse(data))
      })
    })
  },
  findService(where, opts = { page: 1, recordsPerPage: 20 }) {
    return axios.get(`${URL}/Service`, {
      params: opts
    }).then(resp => resp.data)
  },
  getService(item) {
    return axios.get(`${URL}/Service/${item._id}`, item).then(resp => resp.data)
  },
  insertService(item) {
    return axios.post(`${URL}/Service`, item).then(resp => resp.data)
  },
  deleteService(_id) {
    return axios.delete(`${URL}/Service/${_id}`).then(resp => resp.data)
  },
  getConfig() {
    return axios.get(`${URL}/MonitorConfig`).then(resp => resp.data)
  },
  saveConfig(config) {
    return axios.post(`${URL}/MonitorConfig`, config).then(resp => resp.data)
  },
  getMailConfig() {
    return axios.get(`${URL.substr(0, URL.lastIndexOf('/'))}/mail/Config`).then(resp => resp.data)
  }
}
