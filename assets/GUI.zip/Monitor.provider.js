import axios from 'axios'
import socketio from 'socket.io-client'

export default {
  url: '${url}',
  listen(cb) {
    return axios.get(`${this.url}/WSSession`).then(resp => resp.data).then(session => {
      const io = socketio(this.url.substr(0, this.url.lastIndexOf('/')) + '/msg', {
        transports: ['websocket'],
        query: {
          name: 'Monitor'
        }
      })
      io.emit('register', session)
      io.on(session, (data) => {
        cb(JSON.parse(data))
      })
    })
  },
  findService(where, opts = { page: 1, recordsPerPage: 20 }) {
    return axios.get(`${this.url}/Service`, {
      params: opts
    }).then(resp => resp.data)
  },
  getService(item) {
    return axios.get(`${this.url}/Service/${item._id}`, item).then(resp => resp.data)
  },
  insertService(item) {
    return axios.post(`${this.url}/Service`, item).then(resp => resp.data)
  },
  deleteService(_id) {
    return axios.delete(`${this.url}/Service/${_id}`).then(resp => resp.data)
  },
  getConfig() {
    return axios.get(`${this.url}/MonitorConfig`).then(resp => resp.data)
  },
  saveConfig(config) {
    return axios.post(`${this.url}/MonitorConfig`, config).then(resp => resp.data)
  },
  getMailConfig() {
    return axios.get(`${this.url}/MailConfig`).then(resp => resp.data)
  }
}
