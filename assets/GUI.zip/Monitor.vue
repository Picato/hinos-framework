<template>
  <Page title="Service monitoring" subtitle="Monitor all of services" :breadcrumb="['Manager', 'Monitoring']">
    <template slot="main">
      <form @submit.prevent="save()" class="field is-horizontal">
        <div class="field-body">
          <div class="field">
            <label class="label">Mail sending config</label>
            <p class="control has-icons-left is-normal" style="width: 100%">
              <div class="select">
                <select v-model="config.mailConfigId">
                  <option :value="c._id" v-for="c in mailConfig" :key="c._id">{{c.name}}</option>
                </select>
              </div>
            </p>
          </div>
          <div class="field">
            <label class="label">Email to when got error</label>
            <p class="control has-icons-left is-expanded" style="width: 100%">
              <input class="input is-fullwidth" v-model="config.mailTo" type="text" placeholder="admin@admin.com, mod@gmail.com">
              <span class="icon is-left">
                <i class="fa fa-envelope" style="text-shadow: none"></i>
              </span>
            </p>
          </div>
          <div class="field">
            <label class="label">&nbsp;</label>
            <button class="button is-primary" type="submit">
              <span class="icon">
                <i class="fa fa-save"></i>
              </span>&nbsp; Save configuration
            </button>
          </div>
        </div>
      </form>
      <br/>
      <br/>
      <div class="tile">
        <div class="tile">
          <div class="tile is-child box has-text-centered notification">
            <p class="title">
              <span class="icon">
                <i class="fa fa-desktop"></i>
              </span>&nbsp;Monitoring</p>
            <br/>
            <br/>
            <div class="block">
              <div class="box notification is-pulled-left" v-for="service in list" :key="service._id" :class="{'is-danger': service.status === -1, 'is-success': service.status === 1}">
                <a class="delete is-small" @click="remove(service)"></a>
                <div class="tag">
                  <span class="icon">
                    <i class="fa fa-television"></i>
                  </span>&nbsp;{{service.name.toUpperCase()}}
                </div>
                <br/>
                <br/>
                <div>
                  {{service.link}}
                </div>
                <pre class="has-text-left" v-show="service.logs.length > 0"><div :class="{'has-text-danger': a.status === -1, 'has-text-success': a.status === 1}" v-for="a in service.logs" :key="a._id"><b>[{{a.created_at | $date('DD/MM/YYYY HH:mm:ss')}}]</b> {{a.error || 'Passed'}}</div></pre>
              </div>
              <div class="box notification is-pulled-left">
                <form @submit.prevent="add()" class="has-text-left">
                  <div class="field">
                    <label class="label">Name</label>
                    <p class="control">
                      <input class="input" :class="{'is-danger': errors.has('name')}" type="text" placeholder="name" v-model.trim="item.name" name="name" v-validate="'required'">
                    </p>
                    <p class="help is-danger" v-show="errors.has('name')">{{ errors.first('name') }}</p>
                  </div>
                  <div class="field">
                    <label class="label">IP & Port</label>
                    <p class="control">
                      <input class="input" :class="{'is-danger': errors.has('link')}" type="text" placeholder="ip:port" v-model.trim="item.link" name="link" v-validate="'required'">
                    </p>
                    <p class="help is-danger" v-show="errors.has('link')">{{ errors.first('link') }}</p>
                  </div>
                  <br/>
                  <button class="button is-primary" type="submit">
                    <span class="icon">
                      <i class="fa fa-plus"></i>
                    </span>
                    &nbsp;&nbsp;Add New service
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </template>
  </Page>
</template>

<script>
import _ from 'lodash'
import { $find, $show, $date } from '@/filters/Core'
import Page from '@/components/template/Page'
import PopupComponent from '@/components/common/Popup.component'
import ConfirmComponent from '@/components/common/Confirm.component'
import MonitorProvider from '@/providers/Monitor.provider'

export default {
  name: 'list',
  filters: {
    $find,
    $show,
    $date
  },
  components: { PopupComponent, ConfirmComponent, Page },
  data() {
    return {
      url: MonitorProvider.url,
      list: [],
      item: {},
      config: {},
      mailConfig: []
    }
  },
  mounted() {
    this.fetchData()
    MonitorProvider.getMailConfig().then(config => {
      this.mailConfig = config
      MonitorProvider.getConfig().then(config => {
        this.config = _.merge(config, {
          mailTo: config.mailTo ? config.mailTo.join(', ') : ''
        })
        if (!this.config.mailConfigId) this.config.mailConfigId = (this.mailConfig && this.mailConfig.length > 0) ? this.mailConfig[0]._id : undefined
      })
    })
    MonitorProvider.listen((data) => {
      const s = this.list.find(e => e._id === data.service_id)
      s.logs.splice(0, 0, data)
      if (s.status !== data.status) {
        if (data.status === -1) s.status = -1
        else if (data.status === 1) s.status = 1
      }
      if (data.status === -1) {
        this.$pub('msg', { type: -1, msg: `#Monitor: ${data.error}` })
      }
    })
  },
  watch: {
    '$route'({ name }) {
      if (name === 'Log') this.fetchData()
    }
  },
  methods: {
    fetchData(page = 1) {
      this.page = page
      return MonitorProvider.findService(undefined, { page: this.page, recordsPerPage: this.recordsPerPage }).then(data => this.list = data)
    },
    add() {
      this.$validator.validateAll().then((isValid) => {
        if (isValid) {
          if (!this.item._id) {
            this.item.link = this.item.link.replace('https://', '').replace('http://', '')
            MonitorProvider.insertService(this.item).then(rs => this.fetchData().then(rs => this.$pub('msg', { type: 1, msg: `Added successfully` })))
          }
        }
      })
    },
    remove(service) {
      MonitorProvider.deleteService(service._id).then(rs => this.fetchData().then(rs => this.$pub('msg', { type: 1, msg: `Deleted successfully` })))
    },
    save() {
      console.log(this.config.mailTo)
      MonitorProvider.saveConfig({
        secretKey: this.config.secretKey,
        mailConfigId: this.config.mailConfigId,
        mailTo: this.config.mailTo ? this.config.mailTo.split(',').map(e => e.trim()).filter(e => e.length > 0) : []
      }).then(() => {
        this.$pub('msg', { type: 1, msg: `Saved config successfully` })
      })
    }
  }
}
</script>
<style scoped>
.block>.box {
  margin: 16px;
  float: left;
  width: 21%;
  padding: 16px 0px 0px;
}

.block>.box:last-child {
  padding: 16px;
}

pre {
  width: 100%;
  max-height: 200px;
  overflow-y: auto;
  padding: 4px 8px;
  margin-top: 8px;
  font-size: 10px;
}
</style>
