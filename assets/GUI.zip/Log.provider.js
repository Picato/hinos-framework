import axios from 'axios'

export default {
  url: '${url}',
  find(where, opts = { page: 1, recordsPerPage: 20 }) {
    return axios.get(`${this.url}`, {
      params: opts
    }).then(resp => resp.data)
  },
  get(item) {
    return axios.get(`${this.url}/${item._id}`, item).then(resp => resp.data)
  },
  insert(item) {
    return axios.post(`${this.url}`, item).then(resp => resp.data)
  },
  update(item) {
    return axios.put(`${this.url}/${item._id}`, item).then(resp => resp.data)
  },
  delete(_id) {
    return axios.delete(`${this.url}/${_id}`).then(resp => resp.data)
  }
}
