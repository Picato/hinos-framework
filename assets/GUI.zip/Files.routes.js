import { URL } from '@/providers/Files.provider'

export default [
  { path: '/fileconfig', name: 'FileConfig', component: require('@/components/FileConfig'), icon: 'fa-wrench', group: 'File services', link: URL },
  { path: '/files', name: 'Files', component: require('@/components/Files'), icon: 'fa-upload', group: 'File services', link: URL }
]
