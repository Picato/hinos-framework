<template>
  <Page>
    <template slot="others">
      <Confirm :show="action === -1" title="Do you want to delete it ?" @yes="remove()" @no="item=undefined"></Confirm>
    </template>
    <template slot="breadcrumb">
      <li>
        <a>Oauth service</a>
      </li>
      <li class="is-active">
        <a>Uploading files</a>
      </li>
    </template>
    <template slot="title">
      <h1 class="title">Uploading files</h1>
      <h2 class="subtitle">Manage uploading file</h2>
    </template>
    <template slot="main">
      <nav class="pagination is-left" v-if="list">
        <a class="pagination-previous" title="This is the first page" @click="page <= 1 ? null : fetchData(page - 1)" :disabled="page <= 1">Previous</a>
        <a class="pagination-next" @click="list.length < recordsPerPage ? null : fetchData(page + 1)" :disabled="list.length < recordsPerPage">Next page</a>
        <ul class="pagination-list">
          <li>
            <div class="field has-addons">
              <p class="control">
                <a class="button is-static">
                  Page {{page}}
                </a>
              </p>
              <p class="control">
                <span class="select">
                  <select v-model="recordsPerPage" @change="fetchData(1)">
                    <option :value="20">Show 20 records</option>
                    <option :value="50">Show 50 records</option>
                    <option :value="100">Show 100 records</option>
                  </select>
                </span>
              </p>
            </div>
          </li>
        </ul>
      </nav>
      <br>
      <table class="table is-bordered is-striped is-narrow">
        <thead>
          <tr>
            <th width="1">#</th>
            <th>
              <abbr>files</abbr>
            </th>
            <th>
              <abbr>config</abbr>
            </th>
            <th>
              <abbr>created_at</abbr>
            </th>
            <th>
              <abbr>updated_at</abbr>
            </th>
            <th width="1">
            </th>
          </tr>
        </thead>
        <tbody v-if="list">
          <tr v-for="(e, i) in list" :key="e._id">
            <th>{{(page - 1) * recordsPerPage + i + 1}}</th>
            <td>
              <a :href="e.files | $file('link')" :class="{'has-text-dark': e.status === 0, 'has-text-success': e.status === 1}">{{ e.files | $file }}</a>
              <a class="button is-small is-pulled-right" @click="store(e)" v-if="e.status === 0" title="Save it">
                <span class="icon is-small">
                  <i class="fa fa-floppy-o"></i>
                </span>
              </a>
            </td>
            <td>{{ e.config_id | $find(fileConfigs) | $show('name') }}</td>
            <td>{{ e.created_at | $date('DD/MM/YYYY hh:mm') }}</td>
            <td>{{ e.updated_at | $date('DD/MM/YYYY hh:mm') }}</td>
            <td>
              <div class="field has-addons">
                <p class="control">
                  <span class="select is-small">
                    <select v-model="e.downloadSize" :disabled="!e.sizes || e.sizes.length === 0">
                      <option :value="undefined">Native</option>
                      <option v-for="s in e.sizes" :key="s.ext" :value="s.ext">.{{s.ext}}</option>
                    </select>
                  </span>
                </p>
                <p class="control">
                  <a class="button is-small is-info" @click="download(e.files, e.downloadSize)">
                    <span class="icon is-small">
                      <i class="fa fa-download"></i>
                    </span>
                  </a>
                </p>
                <p class="control">
                  <a class="button is-small is-dark" @click="item=e.files">
                    <span class="icon is-small">
                      <i class="fa fa-trash-o"></i>
                    </span>
                    <span>Delete</span>
                  </a>
                </p>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </template>
  </Page>
</template>

<script>
import { $find, $show, $date, $file } from '@/filters/Core'
import Page from '@/components/template/Page'
import Popup from '@/components/common/Popup'
import Confirm from '@/components/common/Confirm'
import FileProvider from '@/providers/Files.provider'
import FileConfigProvider from '@/providers/FileConfig.provider'

export default {
  name: 'list',
  filters: {
    $find,
    $show,
    $file,
    $date,
    $status(vl) {
      return vl === 1 ? 'Stored' : 'Temp'
    }
  },
  components: { Popup, Confirm, Page },
  data() {
    return {
      page: 1,
      recordsPerPage: 20,
      item: undefined,
      list: undefined,
      fileConfigs: []
    }
  },
  computed: {
    action() {
      return typeof this.item === 'object' ? 1 : (typeof this.item === 'string' ? -1 : 0)
    }
  },
  mounted() {
    FileConfigProvider.find(undefined, { recordsPerPage: 0 }).then((fileConfigs) => {
      this.fileConfigs = fileConfigs
      this.fetchData(1)
    })
  },
  methods: {
    store(e) {
      FileProvider.store(e.files).then(rs => e.status = 1)
    },
    download(link, ext) {
      const links = link.split('?')
      let downloadLink = links[0]
      if (ext) downloadLink = downloadLink.substr(0, downloadLink.lastIndexOf('.')) + '.' + ext + downloadLink.substr(downloadLink.lastIndexOf('.'))
      window.open(`${FileProvider.url}/${downloadLink}?download=1${links[1] ? `&${links[1]}` : ''}`)
    },
    fetchData(page = 1) {
      this.page = page
      return FileProvider.find(undefined, { page: this.page, recordsPerPage: this.recordsPerPage }).then(data => this.list = data)
    },
    closeUpdate(type) {
      this.item = undefined
      if (type) this.$pub('msg', { type: 1, msg: `${type} successfully` })
    },
    remove() {
      FileProvider.delete(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Deleted')))
    }
  }
}
</script> 

<style scoped>
.tag {
  margin: 0px 1px;
}
</style>
