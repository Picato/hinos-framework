<template>
  <Page title="Uploading files management" subtitle="Manage files in project" :breadcrumb="['File service', 'Uploading files']">
    <template slot="others">
      <ConfirmComponent :show="action === -1" title="Do you want to delete it ?" @yes="remove()" @no="item=undefined"></ConfirmComponent>
    </template>
    <template slot="main">
      <TableComponent>
        <template slot="pagination" v-if="list">
          <a class="pagination-previous" title="This is the first page" @click="page <= 1 ? null : fetchData(page - 1)" :disabled="page <= 1">Previous</a>
          <a class="pagination-next" @click="list.length < recordsPerPage ? null : fetchData(page + 1)" :disabled="list.length < recordsPerPage">Next page</a>
          <ul class="pagination-list">
            <li>
              <div class="field has-addons">
                <p class="control">
                  <a class="button is-static">
                    Page {{page}}
                  </a>
                </p>
                <p class="control">
                  <span class="select">
                    <select v-model="recordsPerPage" @change="fetchData(1)">
                      <option :value="20">Show 20 records</option>
                      <option :value="50">Show 50 records</option>
                      <option :value="100">Show 100 records</option>
                    </select>
                  </span>
                </p>
              </div>
            </li>
          </ul>
        </template>
        <template slot="head">
          <tr>
            <th width="1">#</th>
            <th>files</th>
            <th>config</th>
            <th>created_at</th>
            <th>updated_at</th>
            <th width="1"></th>
          </tr>
        </template>
        <template slot="body" v-if="list">
          <tr v-for="(e, i) in list" :key="e._id">
            <th>{{(page - 1) * recordsPerPage + i + 1}}</th>
            <td>
              <a :href="e.files | $file('link')" :class="{'has-text-dark': e.status === 0, 'has-text-success': e.status === 1}">{{ e.files | $file }}</a>
              <a class="button is-small is-pulled-right" @click="store(e)" v-if="e.status === 0" title="Save it">
                <span class="icon is-small">
                  <i class="fa fa-floppy-o"></i>
                </span>
              </a>
            </td>
            <td>{{ e.config_id | $find(fileConfigs) | $show('name') }}</td>
            <td>{{ e.created_at | $date('DD/MM/YYYY hh:mm') }}</td>
            <td>{{ e.updated_at | $date('DD/MM/YYYY hh:mm') }}</td>
            <td>
              <div class="field has-addons">
                <p class="control">
                  <span class="select is-small">
                    <select v-model="e.downloadSize" :disabled="!e.sizes || e.sizes.length === 0">
                      <option :value="undefined">Native</option>
                      <option v-for="s in e.sizes" :key="s.ext" :value="s.ext">.{{s.ext}}</option>
                    </select>
                  </span>
                </p>
                <p class="control">
                  <a class="button is-small is-info" @click="download(e.files, e.downloadSize)">
                    <span class="icon is-small">
                      <i class="fa fa-download"></i>
                    </span>
                  </a>
                </p>
                <p class="control">
                  <a class="button is-small is-dark" @click="item=e.files">
                    <span class="icon is-small">
                      <i class="fa fa-trash-o"></i>
                    </span>
                    <span>Delete</span>
                  </a>
                </p>
              </div>
            </td>
          </tr>
        </template>
      </TableComponent>
    </template>
  </Page>
</template>

<script>
import { $find, $show, $date } from '@/filters/Core'
import Page from '@/components/template/Page'
import PopupComponent from '@/components/common/Popup.component'
import TableComponent from '@/components/common/Table.component'
import ConfirmComponent from '@/components/common/Confirm.component'
import { FilesProvider, FileConfigProvider, URL } from '@/providers/Files.provider'

export default {
  name: 'list',
  filters: {
    $find,
    $show,
    $date,
    $file(value, type) {
      if (value) {
        return type === 'link' ? `${URL}/${value}` : value.split('name=')[1]
      }
    },
    $status(vl) {
      return vl === 1 ? 'Stored' : 'Temp'
    }
  },
  components: { PopupComponent, ConfirmComponent, Page, TableComponent },
  data() {
    return {
      page: 1,
      recordsPerPage: 20,
      item: undefined,
      list: undefined,
      fileConfigs: []
    }
  },
  computed: {
    action() {
      return typeof this.item === 'object' ? 1 : (typeof this.item === 'string' ? -1 : 0)
    }
  },
  mounted() {
    FileConfigProvider.find(undefined, { recordsPerPage: 0 }).then((fileConfigs) => {
      this.fileConfigs = fileConfigs
      this.fetchData()
    })
  },
  watch: {
    '$route'({ name }) {
      if (name === 'Files') this.fetchData()
    }
  },
  methods: {
    store(e) {
      FilesProvider.store(e.files).then(rs => e.status = 1)
    },
    download(link, ext) {
      const links = link.split('?')
      let downloadLink = links[0]
      if (ext) downloadLink = downloadLink.substr(0, downloadLink.lastIndexOf('.')) + '.' + ext + downloadLink.substr(downloadLink.lastIndexOf('.'))
      window.open(`${URL}/${downloadLink}?download=1${links[1] ? `&${links[1]}` : ''}`)
    },
    fetchData(page = 1) {
      this.page = page
      return FilesProvider.find(undefined, { page: this.page, recordsPerPage: this.recordsPerPage }).then(data => this.list = data)
    },
    closeUpdate(type) {
      this.item = undefined
      if (type) this.$pub('msg', { type: 1, msg: `${type} successfully` })
    },
    remove() {
      FilesProvider.delete(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Deleted')))
    }
  }
}
</script> 

<style scoped>
.tag {
  margin: 0px 1px;
}
</style>
