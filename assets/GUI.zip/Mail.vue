<template>
  <Page title="Mail management" subtitle="Manage mail in project" :breadcrumb="['Mail service', 'Mail']">
    <template slot="others">
      <Confirm :show="action === -1" title="Do you want to delete it ?" @yes="remove()" @no="item=undefined"></Confirm>
      <Popup title="Mail details" :show="action === 1">
        <template slot="body" v-if="item">
          <div class="notification is-danger" v-if="item.error">
            <span class="icon">
              <i class="fa fa-exclamation-triangle"></i>
            </span>
            {{item.error}}
          </div>
          <nav class="panel">
            <p class="panel-heading">
              <span class="icon" title="Mail config">
                <i class="fa fa-cogs"></i>
              </span>
              {{item.config_id | $find(mailConfig) | $show('name')}}
            </p>
            <div class="panel-block">
              <span class="panel-icon" title="Sender">
                <i class="fa fa-address-card"></i>
              </span>
              <span class="tag is-primary">{{item.from}}</span>
            </div>
            <div class="panel-block">
              <span class="panel-icon" title="To">
                <i class="fa fa-mail-forward"></i>
              </span>
              <span class="tag is-info" v-for="f in item.to" :key="f">
                <a :href="'mailto:'+f " class="has-text-light">{{f}}</a>
              </span>
            </div>
            <div class="panel-block">
              <span class="panel-icon" title="CC">
                <i class="fa fa-cc"></i>
              </span>
              <span class="tag is-warning" v-for="f in item.cc" :key="f">
                <a :href="'mailto:'+f " class="has-text-dark">{{f}}</a>
              </span>
            </div>
            <div class="panel-block">
              <span class="panel-icon" title="Subject">
                <i class="fa fa-comment"></i>
              </span>
              {{item.subject}}
            </div>
            <div class="panel-block" v-if="item.attachments && item.attachments.length > 0">
              <span class="panel-icon" title="CC">
                <i class="fa fa-paperclip"></i>
              </span>
              <div align="right is-fullwidth">
                <a class="button is-link" :href="f.path" target="_blank" v-for="f in item.attachments" :key="f">{{f.filename}}</a>
              </div>
            </div>
            <div class="panel-block" v-if="item.text" v-bind:text-content.prop="item.text"></div>
            <div class="panel-block" v-if="item.html" v-html="item.html"></div>
          </nav>
        </template>
        <template slot="footer" v-if="item">
          <a class="button" disabled :class="{'is-warning is-loading': item.status === 0, 'is-success': item.status === 1, 'is-danger': item.status < 0}">
            <span class="icon">
              <i class="fa" :class="{'fa-check': item.status === 1, 'fa-exclamation-triangle': item.status < 0}"></i>
            </span>
            <span>{{item.status | $match({0: 'Pending', 1: 'Sent', '-1': 'Error', '-2': 'Error', '-3': 'Failed'})}}</span>
          </a>
          <a class="button" @click="closeUpdate()">
            <span class="icon">
              <i class="fa fa-times"></i>
            </span>
            <span>Close</span>
          </a>
        </template>
      </Popup>
    </template>
    <template slot="main">
      <TableComponent>
        <template slot="pagination" v-if="list">
          <a class="pagination-previous" title="This is the first page" @click="page <= 1 ? null : fetchData(page - 1)" :disabled="page <= 1">Previous</a>
          <a class="pagination-next" @click="list.length < recordsPerPage ? null : fetchData(page + 1)" :disabled="list.length < recordsPerPage">Next page</a>
          <ul class="pagination-list">
            <li>
              <div class="field has-addons">
                <p class="control">
                  <a class="button is-static">
                    Page {{page}}
                  </a>
                </p>
                <p class="control">
                  <span class="select">
                    <select v-model="recordsPerPage" @change="fetchData(1)">
                      <option :value="20">Show 20 records</option>
                      <option :value="50">Show 50 records</option>
                      <option :value="100">Show 100 records</option>
                    </select>
                  </span>
                </p>
              </div>
            </li>
          </ul>
        </template>
        <template slot="head">
          <tr>
            <th width="1">#</th>
            <th>subject</th>
            <th>status</th>
            <th>to</th>
            <th>created_at</th>
            <th>updated_at</th>
            <th>config</th>
            <th width="1"></th>
          </tr>
        </template>
        <template slot="body" v-if="list">
          <tr v-for="(e, i) in list" :key="e._id">
            <th>{{(page - 1) * recordsPerPage + i + 1}}</th>
            <td>
              {{ e.subject }}
              <span class="icon is-small" title="Got attachment files" v-if="e.attachments && e.attachments.length > 0">
                <i class="fa fa-paperclip"></i>
              </span>
            </td>
            <td>
              <span class="tag" :class="{'is-warning': e.status === 0, 'is-success': e.status === 1, 'is-danger': e.status < 0}">
                {{e.status | $match({0: 'Pending', 1: 'Sent', '-1': 'Error', '-2': 'Error', '-3': 'Failed'})}}
              </span>
            </td>
            <td>
              <span class="tag is-dark" v-for="f in e.to" :key="f">{{f}}</span>
            </td>
            <td>{{ e.created_at | $date("DD/MM/YYYY hh:mm:ss") }}</td>
            <td>{{ e.updated_at | $date("DD/MM/YYYY hh:mm:ss") }}</td>
            <td>
              <span class="tag is-dark">{{ e.config_id | $find(mailConfig) | $show('name') }}</span>
            </td>
            <td>
              <div class="field has-addons">
                <p class="control">
                  <a class="button is-small is-primary" @click="e.status !== 0 ? resend(e) : undefined" :disabled="e.status === 0">
                    <span class="icon is-small">
                      <i class="fa fa-refresh"></i>
                    </span>
                    <span>Resend</span>
                  </a>
                </p>
                <p class="control">
                  <a class="button is-small is-info" @click="openUpdate(e)">
                    <span class="icon is-small">
                      <i class="fa fa-eye"></i>
                    </span>
                    <span>Details</span>
                  </a>
                </p>
                <p class="control">
                  <a class="button is-small is-dark" @click="item=e._id">
                    <span class="icon is-small">
                      <i class="fa fa-trash-o"></i>
                    </span>
                    <span>Delete</span>
                  </a>
                </p>
              </div>
            </td>
          </tr>
        </template>
      </TableComponent>
    </template>
  </Page>
</template>

<script>
import { $find, $show, $date, $match } from '@/filters/Core'
import Page from '@/components/template/Page'
import Popup from '@/components/common/Popup'
import TableComponent from '@/components/common/Table.component'
import Confirm from '@/components/common/Confirm'
import MailProvider from '@/providers/Mail.provider'
import MailConfigProvider from '@/providers/MailConfig.provider'

export default {
  name: 'list',
  filters: { $find, $show, $date, $match },
  components: { Popup, Confirm, Page, TableComponent },
  data() {
    return {
      page: 1,
      recordsPerPage: 20,
      mailConfig: [],
      item: undefined,
      list: undefined
    }
  },
  computed: {
    action() {
      return typeof this.item === 'object' ? 1 : (typeof this.item === 'string' ? -1 : 0)
    }
  },
  mounted() {
    MailConfigProvider.find(undefined, { recordsPerPage: 0 }).then((mailConfig) => {
      this.mailConfig = mailConfig
      this.fetchData()
    })
  },
  watch: {
    '$route'({ name }) {
      if (name === 'Mail') this.fetchData()
    }
  },
  methods: {
    fetchData(page = 1) {
      this.page = page
      return MailProvider.find(undefined, { page: this.page, recordsPerPage: this.recordsPerPage }).then(data => this.list = data)
    },
    openUpdate(item = {}) {
      MailProvider.get(item).then((item) => {
        this.item = item
      })
    },
    closeUpdate(type) {
      this.item = undefined
      if (type) this.$pub('msg', { type: 1, msg: `${type} successfully` })
    },
    resend(item) {
      MailProvider.resend(item).then(rs => {
        item.status = 0
        this.$pub('msg', { type: 1, msg: `Pushed this email back to queue` })
      })
    },
    remove() {
      MailProvider.delete(this.item).then(rs => this.fetchData().then(rs => this.closeUpdate('Deleted')))
    }
  }
}
</script> 
