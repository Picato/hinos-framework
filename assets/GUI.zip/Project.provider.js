import axios from 'axios'

export default {
  url: '${url}',
  get() {
    return axios.get(`${this.url}/Project`).then(resp => resp.data)
  },
  find(where, opts = { page: 1, recordsPerPage: 1 }) {
    return axios.get(`${this.url}/Projects`, {
      params: opts
    }).then(resp => resp.data)
  },
  insert(item) {
    return axios.post(`${this.url}/Project`, item).then(resp => resp.data)
  },
  update(item) {
    return axios.put(`${this.url}/Project/${item._id}`, item).then(resp => resp.data)
  },
  updateMine(item) {
    return axios.put(`${this.url}/Project`, item).then(resp => resp.data)
  },
  delete(_id) {
    return axios.delete(`${this.url}/Project/${_id}`).then(resp => resp.data)
  }
}
